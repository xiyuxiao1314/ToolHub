import pathlib, os, sqlite3, subprocess, json, uuid, sys
sys.stdout.reconfigure(encoding='utf-8')
base=pathlib.Path(__file__).parent / ('seeded-'+uuid.uuid4().hex[:8])
base.mkdir()
db=base/'registry.sqlite'
env=os.environ.copy()
env['TOOLHUB_REGISTRY']=str(db)
env['USERPROFILE']='C:\\Users\\hp'
env['USERNAME']='hp'
exe=os.environ['R1_TOOLHUBD']
seq=0
def call(method,params):
    global seq
    seq+=1
    req=json.dumps({'jsonrpc':'2.0','id':seq,'method':method,'params':params})+'\n'
    done=subprocess.run([exe],input=req,env=env,capture_output=True,text=True,encoding='utf-8',timeout=15)
    return json.loads(done.stdout)
call('ping',{})
conn=sqlite3.connect(db)
conn.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES ('org.python.python','Python','t','t')")
conn.execute("INSERT INTO tool_capabilities VALUES ('org.python.python','language.python.execute')")
insert="""INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,trust_json,status,first_seen,last_seen)
VALUES (?, 'org.python.python', ?, 'windows', ?, ?, ?, 'available','t','t')"""
conn.execute(insert,('blocked-python','3.13.0','aarch64','C:/Users/hp/secret-project/python.exe','{"level":"blocked"}'))
conn.commit()
print('blocked_only=' + json.dumps(call('resolve.capability',{'capability':'language.python.execute','arch':'x86_64','require_trust':'verified'}),ensure_ascii=False))
print('export=' + json.dumps(call('export.report',{}),ensure_ascii=False))
conn.execute("UPDATE tool_instances SET version='3.13.0-rc1',trust_json='{"+'"level":"known"'+"}'")
conn.commit()
print('prerelease_min=' + json.dumps(call('resolve.capability',{'capability':'language.python.execute','version':'>=3.13.0'}),ensure_ascii=False))
conn.execute("UPDATE tool_instances SET version='0.9.0'")
conn.commit()
print('caret_0_2=' + json.dumps(call('resolve.capability',{'capability':'language.python.execute','version':'^0.2.0'}),ensure_ascii=False))
print('artifacts='+str(base))
