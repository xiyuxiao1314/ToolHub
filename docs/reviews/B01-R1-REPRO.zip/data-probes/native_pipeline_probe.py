import pathlib, os, sqlite3, subprocess, json, time, uuid, sys
sys.stdout.reconfigure(encoding='utf-8')

base = pathlib.Path(__file__).parent / ('native-' + uuid.uuid4().hex[:8])
base.mkdir()
db = base / 'registry.sqlite'
root = base / 'fixture'
root.mkdir()
bins = [root/'project-a'/'.venv'/'Scripts', root/'project-b'/'.venv'/'Scripts']
for b in bins:
    b.mkdir(parents=True)
    (b/'python.exe').write_bytes(b'harmless metadata fixture, never executed')
(bins[0]/'unknown.exe').write_bytes(b'harmless unknown fixture')
env = os.environ.copy()
env.update({'TOOLHUB_REGISTRY':str(db),'PATH':os.pathsep.join(str(b) for b in bins),
            'ProgramFiles':str(root),'ProgramFiles(x86)':str(root),'LOCALAPPDATA':str(root),
            'USERPROFILE':str(root),'HOME':str(root),'USERNAME':'hp'})
exe = pathlib.Path(os.environ['R1_TOOLHUBD'])
seq=0
def call(method,params):
    global seq
    seq+=1
    req=json.dumps({'jsonrpc':'2.0','id':seq,'method':method,'params':params})+'\n'
    done=subprocess.run([str(exe)],input=req,env=env,capture_output=True,text=True,encoding='utf-8',timeout=25)
    if done.returncode:
        raise RuntimeError(done.stderr)
    return json.loads(done.stdout)['result']

first=call('scan.start',{'mode':'quick'})
conn=sqlite3.connect(db)
def records():
    return conn.execute('SELECT id,path,environment_id,version,arch,status,last_seen FROM tool_instances WHERE path LIKE ?',('%'+base.name+'%',)).fetchall()
rows1=records()
unknown1=conn.execute('SELECT count(*) FROM scan_candidates WHERE path LIKE ?',('%'+base.name+'%',)).fetchone()[0]
time.sleep(.1)
second=call('scan.start',{'mode':'full'})
rows2=records()
unknown2=conn.execute('SELECT count(*) FROM scan_candidates WHERE path LIKE ?',('%'+base.name+'%',)).fetchone()[0]
for b in bins:
    (b/'python.exe').unlink()
third=call('scan.start',{'mode':'quick'})
rows3=records()
resolve=call('resolve.capability',{'capability':'language.python.execute'})
invalid=call('resolve.capability',{'capability':'language.python.execute','version':'>=3.13 || true'})
export=call('export.report',{})
print(json.dumps({'first_scan':first,'second_scan':second,'fixture_rows_first':rows1,'fixture_rows_second':rows2,
  'candidate_counts':[unknown1,unknown2],'third_scan_after_delete':third,'fixture_rows_after_delete':rows3,
  'resolver_after_delete':resolve,'invalid_version_result':invalid,
  'environment_rows':conn.execute('SELECT id,kind,root_path,parent_id FROM environments').fetchall(),
  'native_version_count':conn.execute('SELECT COUNT(*),COUNT(version) FROM tool_instances').fetchone(),
  'evidence_count':conn.execute('SELECT COUNT(*) FROM evidence').fetchone()[0],
  'interface_count':conn.execute('SELECT COUNT(*) FROM interfaces').fetchone()[0],
  'scan_session_count':conn.execute('SELECT COUNT(*) FROM scan_sessions').fetchone()[0],
  'exports_fixture': [x for x in export['tools'] if base.name in x.get('path','')],
  'artifacts':str(base)},ensure_ascii=False,indent=2))
