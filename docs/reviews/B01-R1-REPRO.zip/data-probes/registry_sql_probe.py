import pathlib, re, sqlite3, json

checkout = pathlib.Path(__file__).parent.parent / 'checkout'
repo = (checkout / 'crates/registry/src/repo.rs').read_text(encoding='utf-8')
sql = (checkout / 'crates/registry/src/migrations/001_init.sql').read_text(encoding='utf-8')
conn = sqlite3.connect(':memory:')
conn.executescript(sql)
def query(start):
    return next(s for s in re.findall(r'"((?:[^"\\]|\\.)*)"', repo) if s.startswith(start))
def upsert(iid, version, seen):
    params = [iid,'org.python.python',version,'windows','x86_64','C:/fixture/python.exe','C:/fixture/python.exe','env.system','{}','{}','{"level":"known"}','available',seen]
    conn.execute(query('INSERT INTO tool_definitions'), ['org.python.python','Python',seen])
    conn.execute(query('INSERT INTO tool_instances('),params)

conn.execute("INSERT INTO environments(id,name,kind) VALUES ('env.system','System','system')")
upsert('inst-first','3.12','2026-09-29T01:00:00Z')
conn.commit()
try:
    upsert('inst-second','3.13','2026-09-29T02:00:00Z')
    conn.commit()
    print('repeat_scan_write=accepted')
except sqlite3.IntegrityError as e:
    conn.rollback()
    print('repeat_scan_write=' + str(e))
print('retained_instance=' + json.dumps(conn.execute('SELECT id,version,last_seen FROM tool_instances').fetchall()))
for cid in ('candidate-first','candidate-second'):
    conn.execute(query('INSERT INTO scan_candidates('),[cid,'C:/fixture/unknown.exe','unknown.exe',0,'2026-09-29T02:00:00Z'])
print('same_path_candidate_count=' + str(conn.execute("SELECT COUNT(*) FROM scan_candidates WHERE path='C:/fixture/unknown.exe'").fetchone()[0]))
print('evidence_rows=' + str(conn.execute('SELECT COUNT(*) FROM evidence').fetchone()[0]))
print('scan_session_rows=' + str(conn.execute('SELECT COUNT(*) FROM scan_sessions').fetchone()[0]))
