import json
import os
import queue
import sqlite3
import subprocess
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'protocol-probes'
OUT.mkdir(exist_ok=True)
BIN = Path(r'C:\Users\hp\AppData\Local\Temp\toolhub-codex-r1-46a06aa-target\release')
results = []

class Rpc:
    def __init__(self, db, mcp=False, listen=False):
        env = dict(os.environ, TOOLHUB_REGISTRY=str(db), TOOLHUBD_BIN=str(BIN / 'toolhubd.exe'))
        command = [str(BIN / 'toolhub.exe'), 'mcp', 'serve'] if mcp else [str(BIN / 'toolhubd.exe')]
        if listen:
            command.append('--listen')
        self.log = open(OUT / f'{db.stem}-stderr.log', 'w', encoding='utf-8')
        self.p = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=self.log, text=True, encoding='utf-8', env=env)
        self.lines = queue.Queue()
        def read():
            for line in self.p.stdout:
                self.lines.put(line)
            self.lines.put(None)
        threading.Thread(target=read, daemon=True).start()
        self.next_id = 0

    def request(self, method, params=None, **extra):
        self.next_id += 1
        message = {'jsonrpc': '2.0', 'id': self.next_id, 'method': method,
                   'params': {} if params is None else params}
        message.update(extra)
        if message.get('id') == '__omit__':
            del message['id']
        self.p.stdin.write(json.dumps(message) + '\n')
        self.p.stdin.flush()
        line = self.lines.get(timeout=5)
        return None if line is None else json.loads(line)

    def close(self):
        if self.p.poll() is None:
            self.p.stdin.close()
            try:
                self.p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.p.kill()
                self.p.wait(timeout=3)
        self.log.close()

db = OUT / 'protocol.sqlite'
rpc = Rpc(db)
results.append({'probe': 'invalid-jsonrpc-envelope', 'response': rpc.request('ping', 7, jsonrpc='1.0', id={'invalid': True})})
oversized = rpc.request('ping', {'padding': 'x' * (1024 * 1024 + 100)})
results.append({'probe': 'oversized-stdio-request', 'request_bytes_over_1mib': True, 'accepted': 'result' in oversized})
results.append({'probe': 'resolve-wire-shape', 'response': rpc.request('resolve.capability', {'capability': 'language.python.execute'})})
results.append({'probe': 'export-wire-shape', 'response': rpc.request('export.report')})

with sqlite3.connect(db) as c:
    c.execute("INSERT OR REPLACE INTO skills(id,name,schema,kind,manifest_json,path) VALUES(?,?,?,?,?,?)",
              ('r1.skill', 'R1 synthetic skill', 'toolhub.skill/v1', 'instruction', '{}', 'fixture/SKILL.md'))
results.append({'probe': 'registered-skill-not-visible', 'stored_rows': 1,
                'list': rpc.request('skill.list'), 'inspect': rpc.request('skill.inspect', {'id': 'r1.skill'})})
session = rpc.request('discovery.start', {'agent_id': 'r1.agent'})['result']['session_id']
classified = rpc.request('discovery.classify', {'session_id': session})
with sqlite3.connect(db) as c:
    evidence_count = c.execute('SELECT count(*) FROM evidence').fetchone()[0]
results.append({'probe': 'empty-classification-falsely-stored', 'response': classified, 'evidence_rows': evidence_count})
rpc.close()

env = dict(os.environ, TOOLHUB_REGISTRY=str(db), TOOLHUBD_BIN=str(BIN / 'toolhubd.exe'))
def cli(*args):
    p = subprocess.run([str(BIN / 'toolhub.exe'), '--json', *args], env=env,
                       capture_output=True, text=True, encoding='utf-8', timeout=5)
    return {'exit': p.returncode, 'stdout': p.stdout.strip(), 'stderr_last': p.stderr.strip().splitlines()[-1:]}
results.append({'probe': 'cli-json-error', 'response': cli('inspect', 'r1.missing-instance')})
cli('policy', 'set', 'tool', 'r1.synthetic-tool', 'deny')
policy = json.loads(cli('policy', 'get')['stdout'])
results.append({'probe': 'policy-not-reloaded', 'stored_rule_present': any((r.get('subject') if isinstance(r, dict) else r[1]) == 'r1.synthetic-tool' for r in policy['stored']),
                'effective_rule_present': any(r.get('subject') == 'r1.synthetic-tool' for r in policy['defaults'])})

mcp = Rpc(OUT / 'mcp.sqlite', mcp=True)
init = mcp.request('initialize', {'protocolVersion': '2024-11-05', 'capabilities': {}, 'clientInfo': {'name': 'r1', 'version': '1'}})
notification = mcp.request('notifications/initialized', {}, id='__omit__')
tool_list = mcp.request('tools/list')
call = mcp.request('tools/call', {'name': 'search_tools', 'arguments': {'query': ''}})
failed_call = mcp.request('tools/call', {'name': 'inspect_tool', 'arguments': {'id': 'r1.missing-instance'}})
mcp.p.wait(timeout=3)
results.append({'probe': 'mcp-contract-and-error-lifetime', 'initialize': init, 'notification_reply': notification,
                'tools_list_result_type': type(tool_list.get('result')).__name__, 'tools_call_result': call,
                'failed_call_response': failed_call, 'gateway_exit_on_tool_error': mcp.p.returncode})
mcp.close()

report = {'reviewed_head': '46a06aa11c370b2ca4432909aa2b8b0a70127090', 'probes': results}
(OUT / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
