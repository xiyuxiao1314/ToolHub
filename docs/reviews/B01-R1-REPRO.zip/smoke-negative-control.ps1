$ErrorActionPreference = 'Stop'
$fixtureRoot = Join-Path $PSScriptRoot 'smoke-negative-control'
New-Item -ItemType Directory -Path (Join-Path $fixtureRoot 'scripts'),(Join-Path $fixtureRoot 'target\release') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'checkout\scripts\smoke.ps1') -Destination (Join-Path $fixtureRoot 'scripts\smoke.ps1')
$stubText = "@echo off`r`necho SYNTHETIC_NATIVE_FAILURE 1>&2`r`nexit /b 9`r`n"
[IO.File]::WriteAllText((Join-Path $fixtureRoot 'target\release\toolhub.cmd'), $stubText, [Text.Encoding]::ASCII)
$logPath = Join-Path $PSScriptRoot 'evidence\smoke-negative-control.log'
& 'D:\codex\apps\PowerShell\7\pwsh.exe' -NoLogo -NoProfile -File (Join-Path $fixtureRoot 'scripts\smoke.ps1') *> $logPath
$smokeExit = $LASTEXITCODE
$logText = Get-Content -LiteralPath $logPath -Raw -Encoding utf8
$evidence = [ordered]@{
    smoke_exit_code = $smokeExit
    failing_native_commands = [regex]::Matches($logText, 'SYNTHETIC_NATIVE_FAILURE').Count
    still_claimed_done = $logText.Contains('SMOKE DONE')
    unknown_marker_fixture_created = $false
}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'evidence\smoke-negative-control.json'), ($evidence | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
$evidence | ConvertTo-Json
