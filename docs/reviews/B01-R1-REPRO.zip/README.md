# Selected B01 R1 reproduction material

These are the exact reviewer fixture scripts used on Windows for HEAD 46a06aa, plus selected synthetic result files. They are defect reproductions, not a finished test suite. They were not rerun against a repair revision. No binary, SQLite database, real secret, machine scan inventory or environment dump is shipped.

Extract to a new owned directory. Do not run against a user/production registry. Each script selects a private fixture database; preserve any prior results and use a new extraction for each baseline run. Python stdlib is sufficient. If a repaired contract changes method/DTO/table names, translate fixtures and assert the repaired behavior rather than expecting the old failure outputs.

Inputs:

- `protocol-probes.py`: edit its single `BIN` constant to the reviewed release directory containing toolhub.exe/toolhubd.exe. It creates protocol-probes/protocol.sqlite; run once in a fresh extraction.
- `security-probes/security_probe.py`: run with the absolute daemon binary as its first argument; uses the current Python executable for harmless print/sleep/output fixtures, and refuses an existing fixture database.
- `security-probes/extra_probe.py`, then `privacy_probe.py`: run with the daemon path after security_probe; reuse only that synthetic database. extra_probe's memory measurement uses Windows process counters.
- `data-probes/native_pipeline_probe.py` and `seeded_resolver_export_probe.py`: set session-local `R1_TOOLHUBD` to the daemon binary. Each creates a random fresh fixture subdirectory; native_pipeline creates two harmless text files named python.exe and deletes only those owned files after discovery. It reads scoped fixture roots and the scanner's built-in shallow roots, never executes them.
- `data-probes/registry_sql_probe.py`: expects a read-only exact checkout at `checkout` alongside data-probes; adjust that source path as necessary. Uses SQLite memory and extracted source INSERT statements.
- `smoke-negative-control.ps1`: expects the reviewed `checkout/scripts/smoke.ps1`; adjust its explicit PowerShell binary path. It copies smoke into an owned fixture with a harmless command shim that always fails. Failure of every command must make a repaired smoke nonzero.

Review local stderr and use outer bounded process supervision when adapting scripts; some original synchronous client calls intentionally reproduce the baseline's lack of runtime bounds. A native-provider result can vary with built-in roots; the stable assertions concern the owned fixture rows, not total machine counts.

The `observed` result files are selected original evidence. Synthetic username/path/sentinel values are deliberately included to show redaction defects. The sanitized `B01-R1-EVIDENCE.json` separately records command outcomes and hashes. Do not treat observations of old defects as passing repair assertions.
