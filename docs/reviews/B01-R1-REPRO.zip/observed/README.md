Selected original baseline observations only; scripts create fresh outputs outside observed. Synthetic values demonstrate defects.
