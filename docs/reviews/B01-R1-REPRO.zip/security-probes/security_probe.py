import json
import os
import pathlib
import sqlite3
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
DAEMON = pathlib.Path(sys.argv[1])
PYTHON = pathlib.Path(sys.executable)
REGISTRY = ROOT / 'security-fixture-v2.sqlite'
ENV = dict(os.environ, TOOLHUB_REGISTRY=str(REGISTRY))

class Client:
    def __init__(self):
        self.stderr = open(ROOT / f'daemon-{time.time_ns()}.stderr.txt', 'w', encoding='utf-8')
        self.p = subprocess.Popen([str(DAEMON)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr, text=True, encoding='utf-8', env=ENV)
        self.seq = 0
    def call(self, method, params=None):
        self.seq += 1
        self.p.stdin.write(json.dumps({'jsonrpc':'2.0', 'id':self.seq, 'method':method, 'params':params or {}})+'\n')
        self.p.stdin.flush()
        line = self.p.stdout.readline()
        if not line:
            return {'closed': True, 'exit_code':self.p.wait(timeout=5)}
        return json.loads(line)
    def close(self):
        if self.p.poll() is None:
            self.p.stdin.close()
            self.p.wait(timeout=5)
        self.stderr.close()

if REGISTRY.exists():
    raise SystemExit('Use a fresh fixture path; existing fixture preserved')
initial = Client()
initial.call('ping')
initial.close()
with sqlite3.connect(REGISTRY) as db:
    ts = '2026-09-29T00:00:00Z'
    db.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES (?,?,?,?)", ('fixture.python','Fixture Python',ts,ts))
    db.execute("INSERT INTO tool_instances(id,definition_id,platform,arch,path,canonical_path,environment_id,trust_json,status,first_seen,last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?)", ('fixture-python','fixture.python','windows','x86_64',str(PYTHON),str(PYTHON),'system',json.dumps({'level':'known'}),'available',ts,ts))

out = {}
c = Client()
approved = c.call('execute.approve', {'instance_id':'fixture-python','args':['-c','print(1)'],'agent_id':'agent.one'})
out['approval_created'] = approved
aid = approved['result']['approval_id']
out['ask_with_valid_approval'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c','print(1)'],'agent_id':'agent.one','approval_id':aid})
out['set_allow'] = c.call('policy.set', {'scope':'tool','subject':'*','action':'allow'})
out['changed_approved_args_caller'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c','print(2)'],'agent_id':'agent.two','approval_id':aid})
start = time.monotonic()
out['timeout_1ms_sleep_300ms'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c','import time; time.sleep(0.3)'],'timeout_ms':1})
out['timeout_elapsed_ms'] = round((time.monotonic()-start)*1000)
out['secret_args_execute'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c','print(3)','--token','SYNTHETIC_VALUE_9281']})
with sqlite3.connect(REGISTRY) as db:
    out['stored_secret_args'] = db.execute("SELECT args_redacted FROM execution_records WHERE args_redacted LIKE '%SYNTHETIC_VALUE_9281%'").fetchall()
out['set_environment_deny'] = c.call('policy.set', {'scope':'environment','subject':'system','action':'deny'})
out['environment_deny_execute'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c','print(4)']})
out['set_deny'] = c.call('policy.set', {'scope':'tool','subject':'python','action':'deny'})
c.close()
c = Client()
out['reopened_policy'] = c.call('policy.get')
out['reopened_execute'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c','print(5)']})
c.call('policy.set', {'scope':'tool','subject':'*','action':'allow'})
out['utf8_truncation'] = c.call('execute.tool', {'instance_id':'fixture-python','args':['-c',"import sys; sys.stdout.buffer.write(b'a'+('é'*131073).encode('utf-8'))"]})
c.close()
(ROOT / 'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(out, ensure_ascii=False, indent=2))
