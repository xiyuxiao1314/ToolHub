import json
import os
import pathlib
import sqlite3
import subprocess
import sys

root=pathlib.Path(__file__).resolve().parent
dbpath=root/'security-fixture-v2.sqlite'
env=dict(os.environ,TOOLHUB_REGISTRY=str(dbpath),USERPROFILE='C:\\Users\\hp',USERNAME='hp',OPENAI_API_KEY='SYNTHETIC_ENV_3810')
log=open(root/'privacy.stderr.txt','w',encoding='utf-8')
p=subprocess.Popen([sys.argv[1]],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,encoding='utf-8',env=env)
seq=0
def call(method,params=None):
    global seq
    seq+=1
    p.stdin.write(json.dumps({'jsonrpc':'2.0','id':seq,'method':method,'params':params or {}})+'\n')
    p.stdin.flush()
    return json.loads(p.stdout.readline())
call('policy.set',{'scope':'tool','subject':'*','action':'allow'})
out={}
out['hyphenated_api_key_execution']=call('execute.tool',{'instance_id':'fixture-python','args':['-c','print(7)','--api-key','SYNTHETIC_VALUE_5074']})
out['env_sanitized']=call('execute.tool',{'instance_id':'fixture-python','args':['-c','import os; print(os.environ.get("OPENAI_API_KEY", "ABSENT"))']})
with sqlite3.connect(dbpath) as db:
    out['stored_hyphenated_api_key_args']=db.execute("SELECT args_redacted FROM execution_records WHERE args_redacted LIKE '%SYNTHETIC_VALUE_5074%'").fetchall()
    original=db.execute('SELECT path FROM tool_instances WHERE id=?',('fixture-python',)).fetchone()[0]
    db.execute('UPDATE tool_instances SET path=? WHERE id=?',('c:\\users\\hp\\private\\tool.exe','fixture-python'))
out['case_variant_export']=call('export.report')
with sqlite3.connect(dbpath) as db:
    db.execute('UPDATE tool_instances SET path=? WHERE id=?',(original,'fixture-python'))
p.stdin.close()
p.wait(timeout=5)
log.close()
(root/'privacy-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
