import ctypes
from ctypes import wintypes
import json
import os
import pathlib
import sqlite3
import subprocess
import sys
import threading
import time

ROOT = pathlib.Path(__file__).resolve().parent
DAEMON = sys.argv[1]
REGISTRY = ROOT / 'security-fixture-v2.sqlite'
log = open(ROOT / 'extra.stderr.txt', 'w', encoding='utf-8')
p = subprocess.Popen([DAEMON], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True, encoding='utf-8', env=dict(os.environ, TOOLHUB_REGISTRY=str(REGISTRY)))
seq = 0
def call(method, params=None):
    global seq
    seq += 1
    p.stdin.write(json.dumps({'jsonrpc':'2.0','id':seq,'method':method,'params':params or {}})+'\n')
    p.stdin.flush()
    return json.loads(p.stdout.readline())

out = {}
call('policy.set', {'scope':'tool','subject':'*','action':'allow'})
call('policy.set', {'scope':'agent','subject':'agent.one','action':'deny'})
params = {'instance_id':'fixture-python','args':['-c','print(6)']}
out['agent_deny_honest_label'] = call('execute.tool', dict(params,agent_id='agent.one'))
out['agent_deny_spoofed_label'] = call('execute.tool', dict(params,agent_id='agent.two'))
out['agent_deny_omitted_label'] = call('execute.tool', params)

for trust in ('unknown', 'blocked'):
    with sqlite3.connect(REGISTRY) as db:
        db.execute('UPDATE tool_instances SET trust_json=? WHERE id=?', (json.dumps({'level':trust}),'fixture-python'))
    out[f'trust_{trust}'] = call('execute.tool',params)
with sqlite3.connect(REGISTRY) as db:
    db.execute('UPDATE tool_instances SET trust_json=?,status=? WHERE id=?', (json.dumps({'level':'known'}),'blocked','fixture-python'))
out['status_blocked_trust_known'] = call('execute.tool',params)
with sqlite3.connect(REGISTRY) as db:
    db.execute('UPDATE tool_instances SET status=? WHERE id=?', ('available','fixture-python'))

class Counters(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
k32 = ctypes.WinDLL('kernel32',use_last_error=True)
k32.OpenProcess.restype = wintypes.HANDLE
k32.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
k32.CloseHandle.argtypes = [wintypes.HANDLE]
psapi = ctypes.WinDLL('psapi',use_last_error=True)
psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
h = k32.OpenProcess(0x410,False,p.pid)
def memory():
    counters = Counters()
    counters.cb=ctypes.sizeof(counters)
    if not psapi.GetProcessMemoryInfo(h,ctypes.byref(counters),counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return counters.WorkingSetSize,counters.PeakWorkingSetSize
baseline,_ = memory()
captured=[]
def output_test():
    captured.append(call('execute.tool',{'instance_id':'fixture-python','args':['-c','import sys,time; sys.stdout.buffer.write(b"x"*(16*1024*1024)); sys.stdout.flush(); time.sleep(0.3)']}))
t = threading.Thread(target=output_test)
t.start()
peak=baseline
while t.is_alive():
    working,observed_peak=memory()
    peak=max(peak,working,observed_peak)
    time.sleep(0.01)
t.join()
r = captured[0]['result']
out['output_memory']={'source_bytes':16*1024*1024,'limit_bytes':262144,'daemon_baseline_bytes':baseline,'daemon_peak_bytes':peak,'daemon_peak_growth_bytes':peak-baseline,'response_stdout_bytes':len(r['stdout'].encode('utf-8')),'truncated':r['truncated'],'status':r['status']}
k32.CloseHandle(h)
p.stdin.close()
p.wait(timeout=5)
log.close()
(ROOT/'extra-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
