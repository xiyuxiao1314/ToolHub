import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import struct
import subprocess
import threading
import time
import uuid

root = Path(__file__).resolve().parent
fixture = root / ('listener-' + uuid.uuid4().hex[:8])
fixture.mkdir()
binary = Path(os.environ['R2_TOOLHUBD'])
user = 'codex-r2-' + uuid.uuid4().hex[:8]
pipe = r'\\.\pipe\toolhubd-' + user
env = dict(os.environ, USERNAME=user, TOOLHUB_REGISTRY=str(fixture/'registry.sqlite'))
stderr = open(fixture/'daemon.stderr.log', 'w', encoding='utf-8')
p = subprocess.Popen([str(binary), '--listen'], env=env, stdin=subprocess.DEVNULL,
                     stdout=subprocess.PIPE, stderr=stderr)
k = ctypes.WinDLL('kernel32', use_last_error=True)
k.CreateFileW.argtypes = [wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
k.CreateFileW.restype = wintypes.HANDLE
k.ReadFile.argtypes = [wintypes.HANDLE,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),ctypes.c_void_p]
k.WriteFile.argtypes = k.ReadFile.argtypes
k.CloseHandle.argtypes = [wintypes.HANDLE]
invalid = ctypes.c_void_p(-1).value
out = {'fixture_username': user, 'pipe_endpoint': pipe, 'connection_attempts': 0}
h = invalid
deadline = time.monotonic() + 2
while time.monotonic() < deadline and p.poll() is None:
    h = k.CreateFileW(pipe, 0xC0000000, 0, None, 3, 0, None)
    out['connection_attempts'] += 1
    if h not in (None, invalid):
        break
    time.sleep(.02)
if h not in (None, invalid):
    data = json.dumps({'jsonrpc':'2.0','id':1,'method':'ping','params':{}}).encode()
    frame = struct.pack('>I',len(data))+data
    sent = wintypes.DWORD()
    out['write_ok'] = bool(k.WriteFile(h,frame,len(frame),ctypes.byref(sent),None))
    out['written_bytes'] = sent.value
    def read():
        buf = ctypes.create_string_buffer(2048)
        read_count = wintypes.DWORD()
        ok = k.ReadFile(h,buf,len(buf),ctypes.byref(read_count),None)
        out['read_ok'] = bool(ok)
        out['read_bytes'] = read_count.value
        if read_count.value:
            out['response_hex'] = buf.raw[:read_count.value].hex()
        else:
            out['read_error'] = ctypes.get_last_error()
    t = threading.Thread(target=read, daemon=True)
    t.start()
    t.join(2)
    out['read_finished_in_bound'] = not t.is_alive()
else:
    out['connected'] = False
    out['connect_error'] = ctypes.get_last_error()
time.sleep(.1)
out['listener_exited_before_cleanup'] = p.poll() is not None
out['listener_exit_code_before_cleanup'] = p.poll()
if p.poll() is None:
    p.terminate()
p.wait(timeout=3)
if h not in (None,invalid):
    k.CloseHandle(h)
stderr.close()
out['stderr'] = (fixture/'daemon.stderr.log').read_text(encoding='utf-8')[-2000:]
(root/'evidence/listener-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
