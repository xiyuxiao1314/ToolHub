import json
import os
from pathlib import Path
import queue
import sqlite3
import subprocess
import sys
import threading
import time
import uuid

root = Path(__file__).resolve().parent
case = root / ('execution-' + uuid.uuid4().hex[:8])
case.mkdir()
db = case/'registry.sqlite'
daemon = root/'baseline-bin/toolhubd.exe'
env = dict(os.environ, TOOLHUB_REGISTRY=str(db))
env.pop('TOOLHUB_ADMIN', None)
env.pop('TOOLHUB_PRINCIPAL', None)

class Client:
    def __init__(self):
        self.log = open(case/f'stderr-{time.time_ns()}.log','w',encoding='utf-8')
        self.p = subprocess.Popen([str(daemon)],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True,encoding='utf-8')
        self.q = queue.Queue()
        def read():
            for line in self.p.stdout:
                self.q.put(line)
            self.q.put(None)
        threading.Thread(target=read,daemon=True).start()
        self.id=0
    def call(self,method,params=None):
        self.id+=1
        self.p.stdin.write(json.dumps({'jsonrpc':'2.0','id':self.id,'method':method,'params':params or {}})+'\n')
        self.p.stdin.flush()
        line=self.q.get(timeout=4)
        return json.loads(line) if line else {'closed':True}
    def close(self):
        if self.p.poll() is None:
            self.p.stdin.close()
            try:self.p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.p.kill();self.p.wait(timeout=2)
        self.log.close()

c=Client();c.call('ping');c.close()
with sqlite3.connect(db) as conn:
    conn.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES('fixture.python','Fixture Python','t','t')")
    conn.execute("INSERT INTO tool_instances(id,definition_id,platform,arch,path,canonical_path,environment_id,trust_json,status,first_seen,last_seen) VALUES('fixture-python','fixture.python','windows','x86_64',?,?,'env.user','{\"level\":\"known\"}','available','t','t')",(sys.executable,sys.executable))
c=Client()
out={}
args=['-c','print("R2_SAFE")']
apr=c.call('execute.approve',{'instance_id':'fixture-python','args':args})
aid=apr['result']['approval_id']
out['approve_default_client']=apr
out['changed_args']=c.call('execute.tool',{'instance_id':'fixture-python','args':['-c','print("R2_OTHER")'],'approval_id':aid})
out['exact_approved_request']=c.call('execute.tool',{'instance_id':'fixture-python','args':args,'approval_id':aid})
out['replay']=c.call('execute.tool',{'instance_id':'fixture-python','args':args,'approval_id':aid})

def approved_run(code, timeout):
    arguments=['-c',code]
    approval=c.call('execute.approve',{'instance_id':'fixture-python','args':arguments})['result']['approval_id']
    start=time.monotonic()
    result=c.call('execute.tool',{'instance_id':'fixture-python','args':arguments,'approval_id':approval,'timeout_ms':timeout})
    return {'requested_timeout_ms':timeout,'response':result,'elapsed_ms':round((time.monotonic()-start)*1000)}
out['single_child_deadline']=approved_run('import time; time.sleep(.3)',20)
child_code = 'import time; print("R2_FINITE_CHILD",flush=True); time.sleep(.8)'
parent_code = f'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",{child_code!r}]); print("R2_PARENT_READY",flush=True); time.sleep(2)'
out['finite_grandchild_deadline']=approved_run(parent_code,150)
assert out['finite_grandchild_deadline']['response']['result']['status'] == 'timed_out'
assert 'R2_FINITE_CHILD' in out['finite_grandchild_deadline']['response']['result']['stdout']
out['utf8_output']=approved_run('import sys; sys.stdout.buffer.write(b"a" + ("é"*131073).encode("utf-8"))',2000)
out['utf8_output']['response']['result']['stdout_bytes']=len(out['utf8_output']['response']['result']['stdout'].encode())
del out['utf8_output']['response']['result']['stdout']
out['ping_after_cases']=c.call('ping')
c.close()
out['reviewed_head']='7a1ba39a8fb27dddffb4eb662a973c8bedf287ed'
(root/'evidence/execution-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
