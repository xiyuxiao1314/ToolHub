# Selected B01 R2 reproduction evidence

Reviewed immutable baseline: 7a1ba39a8fb27dddffb4eb662a973c8bedf287ed.
Bounded corrections: 6df2166e0c55ec64667021e386e75ca93acb066d (direct child).
All runtime observations included here use verified baseline release binaries.
Policy red/green logs exercise the original/corrected actual repository and daemon.

These selected scripts are evidence helpers, not a completed product test suite.
Inspect before rerunning; adjust checkout/binary/fixture/output paths to a fresh
isolated Windows directory. Existing Python, Cargo/MSVC and native OS APIs were
used. Build the exact baseline with locked dependencies and preserve its binaries
separately before building the corrected branch. Private SQLite fixture databases
and harmless executable/print/sleep cases are created. Never point fixture scripts
at a user registry/database. The finite child case sleeps then exits by itself.
No unknown discovered executable is executed. No external-agent/account, real
credential, macOS build or unauthorized-user pipe result is claimed.

No binaries, SQLite databases, full conversations, environment dumps, real
credentials or user machine discovery inventory are included. Random IDs and
caller labels in observations belong only to isolated synthetic fixture state.
The reports distinguish code omissions from executed checks and host limitations.
