param([string]$Phase = 'baseline')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$checkoutRoot = Join-Path $PSScriptRoot 'checkout'
$vsVars = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$cargoExecutable = 'C:\Users\hp\.cargo\bin\cargo.exe'
$env:CARGO_TARGET_DIR = Join-Path $env:TEMP 'toolhub-codex-r2-7a1ba39-target'
$evidenceRoot = Join-Path $PSScriptRoot 'evidence'
if ($Phase -ne 'baseline') { $evidenceRoot = Join-Path $evidenceRoot $Phase }
New-Item -ItemType Directory -Path $evidenceRoot -Force | Out-Null
Set-Location -LiteralPath $checkoutRoot
$checks = @(
    [PSCustomObject]@{Name='fmt'; Arguments='fmt --all -- --check'},
    [PSCustomObject]@{Name='tests'; Arguments='test --workspace --offline --locked'},
    [PSCustomObject]@{Name='clippy'; Arguments='clippy --workspace --all-targets --offline --locked -- -D warnings'},
    [PSCustomObject]@{Name='build'; Arguments='build --workspace --release --offline --locked'}
)
$results = [Collections.Generic.List[object]]::new()
foreach ($check in $checks) {
    $logFile = Join-Path $evidenceRoot ($check.Name + '.log')
    $nativeCommand = 'call "' + $vsVars + '" >nul && "' + $cargoExecutable + '" ' + $check.Arguments
    & $env:ComSpec /d /s /c $nativeCommand *> $logFile
    $checkExit = $LASTEXITCODE
    $results.Add([PSCustomObject]@{check=$check.Name; exit_code=$checkExit; log=$logFile})
    Write-Host "$($check.Name) exit=$checkExit"
    Get-Content -LiteralPath $logFile -Tail 4 | Write-Host
}
$resultObject = [ordered]@{reviewed_head='7a1ba39a8fb27dddffb4eb662a973c8bedf287ed'; working_tree_phase=$Phase; target_directory=$env:CARGO_TARGET_DIR; checks=@($results.ToArray())}
[IO.File]::WriteAllText((Join-Path $evidenceRoot 'verification.json'), ($resultObject | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
$resultObject | ConvertTo-Json -Depth 5
if (@($results | Where-Object { $_.exit_code -ne 0 }).Count -gt 0) { exit 1 }
