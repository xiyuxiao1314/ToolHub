import pathlib, os, sqlite3, subprocess, json, time, uuid, sys
sys.stdout.reconfigure(encoding='utf-8')
base=pathlib.Path(__file__).parent/('run-'+uuid.uuid4().hex[:8])
base.mkdir()
db=base/'registry.sqlite'
fixture=base/'fixture'
fixture.mkdir()
plain=fixture/'plain'/'bin'
projects=[fixture/'tenant-a'/'same'/'.venv'/'Scripts',fixture/'tenant-b'/'same'/'.venv'/'Scripts']
roots=[plain]+projects
for root in roots:
    root.mkdir(parents=True)
    (root/'python.exe').write_bytes(b'R2 harmless text fixture: metadata only; never execute')
(plain/'unknown-z.exe').write_bytes(b'R2 unknown fixture metadata')
outside=base/'outside-scanned-roots'
outside.mkdir()
(outside/'python.exe').write_bytes(b'R2 outside fixture metadata')
env=os.environ.copy()
env.update({'TOOLHUB_REGISTRY':str(db),'PATH':os.pathsep.join(str(x) for x in roots),
            'ProgramFiles':str(fixture),'ProgramFiles(x86)':str(fixture),'LOCALAPPDATA':str(fixture)})
exe=os.environ['R2_TOOLHUBD']
seq=0
def call(method,params):
    global seq
    seq+=1
    req=json.dumps({'jsonrpc':'2.0','id':seq,'method':method,'params':params})+'\n'
    done=subprocess.run([exe],input=req,env=env,capture_output=True,text=True,encoding='utf-8',timeout=45)
    if done.returncode:
        raise RuntimeError(done.stderr)
    return json.loads(done.stdout)
def fixture_rows():
    return conn.execute('SELECT id,path,environment_id,status,last_seen,trust_json FROM tool_instances WHERE path LIKE ?',('%'+base.name+'%',)).fetchall()

out={'artifacts':str(base)}
out['scan1']=call('scan.start',{'mode':'quick'})
conn=sqlite3.connect(db)
out['fixture_rows_scan1']=fixture_rows()
out['candidate1']=conn.execute('SELECT id,path,canonical_path,size_bytes,metadata_json FROM scan_candidates WHERE path LIKE ?',('%'+base.name+'%',)).fetchall()
time.sleep(.1)
out['scan2']=call('scan.start',{'mode':'quick'})
out['fixture_rows_scan2']=fixture_rows()
out['candidate2']=conn.execute('SELECT id,path,canonical_path,size_bytes,metadata_json FROM scan_candidates WHERE path LIKE ?',('%'+base.name+'%',)).fetchall()
out['environment_rows']=conn.execute('SELECT id,kind,root_path,parent_id FROM environments WHERE id NOT IN (\'env.user\',\'env.system\')').fetchall()

# Existing R1 database identity must survive new recognition IDs.
legacy=conn.execute('SELECT id,path FROM tool_instances WHERE path=?',(str(plain/'python.exe'),)).fetchone()
conn.execute('DELETE FROM interfaces WHERE instance_id=?',(legacy[0],))
conn.execute('UPDATE tool_instances SET id=?,trust_json=?,owner_json=? WHERE id=?',
  ('legacy-r1-instance','{"level":"blocked","reason":"user block"}','{"kind":"user","certainty":"known","id":"user-correction","evidence":[]}',legacy[0]))
conn.commit()
out['scan3_legacy']=call('scan.start',{'mode':'quick'})
out['legacy_after_scan']=conn.execute('SELECT id,status,trust_json,owner_json,last_seen FROM tool_instances WHERE id=\'legacy-r1-instance\'').fetchall()
out['legacy_interfaces']=conn.execute('SELECT instance_id FROM interfaces WHERE instance_id=\'legacy-r1-instance\'').fetchall()

# An existing installed tool outside this scan's visited roots must not be invalidated.
conn.execute('INSERT INTO tool_instances(id,definition_id,platform,arch,path,trust_json,status,first_seen,last_seen) VALUES (?,?,?,?,?,?,?,?,?)',
  ('outside-instance','org.python.python','windows','x86_64',str(outside/'python.exe'),'{"level":"known"}','available','t','t'))
conn.commit()
out['scan4_outside']=call('scan.start',{'mode':'quick'})
out['outside_after_scan']={'exists':(outside/'python.exe').is_file(),'row':conn.execute('SELECT id,status FROM tool_instances WHERE id=\'outside-instance\'').fetchone()}

# Every write error must be surfaced; a recognized path must not become missing due to an ingest error.
conn.execute("CREATE TRIGGER fail_evidence BEFORE INSERT ON evidence WHEN NEW.entity_kind='instance' BEGIN SELECT RAISE(FAIL,'R2 injected evidence write failure'); END")
conn.commit()
out['scan5_injected_error']=call('scan.start',{'mode':'quick'})
out['fixture_rows_after_error']=fixture_rows()
out['scan_sessions']=conn.execute('SELECT status,coverage_json,errors_json FROM scan_sessions ORDER BY started_at').fetchall()
out['metadata_sources_preserved']=conn.execute("SELECT COUNT(*) FROM scan_candidates WHERE metadata_json != '{}' ").fetchone()[0]
out['versions_observed']=conn.execute('SELECT COUNT(*),COUNT(version) FROM tool_instances').fetchone()
out['environment_api']=call('environment.list',{})
out['duplicates_api']=call('environment.duplicates',{})
out['future_version_open']=None
conn.execute('INSERT INTO schema_migrations(version,applied_at) VALUES (999,\'t\')')
conn.commit()
out['future_version_open']=call('ping',{})
result=json.dumps(out,ensure_ascii=False,indent=2)
(base/'results.json').write_text(result,encoding='utf-8')
print(result)
