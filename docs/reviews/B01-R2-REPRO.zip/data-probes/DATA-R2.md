# B01 R2 — Data/scanner/recognition/environment/resolver review

Reviewed exact HEAD `7a1ba39a8fb27dddffb4eb662a973c8bedf287ed` against R1 `46a06aa11c370b2ca4432909aa2b8b0a70127090`. This is one internal domain of formal R2, not a separate formal review. Read the original B01 brief, consolidated R1 findings and repair assignment. The original required scope remains authoritative; delivery labels such as Closed(core) do not waive its subtargets.

No product edits, Cargo commands, installations, cloud actions, OS registry writes or user configuration changes. Private probes used the parent-verified exact-HEAD release binary `C:/Users/hp/AppData/Local/Temp/toolhub-codex-r2-7a1ba39-target/release/toolhubd.exe`, separate owned fixture databases and harmless text files. No fixture or installed unknown tool was executed. Built-in scanners did read bounded native Windows registry/user-root metadata; output evidence retains aggregate counts and our own fixture rows, not a host inventory. Parent owns workspace verification. No macOS build or host test was performed here.

## R1 finding status

| Original finding | Status at delivered R2 HEAD | Positive evidence | Why still open |
| --- | --- | --- | --- |
| F06 registry identity/reconciliation | Partially repaired; P1 open | Ordinary same-path instance ID persists and last_seen advances; identical-text candidate count/ID stable; scan_sessions/evidence/interfaces now have write paths | First nonbuiltin environment insertion fails; old IDs marked Missing; canonical aliases duplicate; global missing reconciliation; ignored write failures; user trust/owner clobber; candidate normalization/metadata loss; migration/refusal/recovery gaps |
| F07 recognition trust/resources | Partially repaired; P1 open | A basename-only rule with low path confidence can now get Unknown trust | PathPattern confidence 0.9 is still treated as corroboration; Python's basename itself satisfies path substring. Harmless plain/bin/python.exe is Known. No metadata/version/architecture/resource loading or representative fixtures |
| F08 native providers/modes | Partially repaired; P2 open | Real read-only winreg App Paths/Uninstall reads exist; Quick now skips PackageManagerProvider | Metadata discarded/unused; coverage still hides missing/errors/caps; package/macOS/SDK/environment metadata absent; no incremental/watch/debounce/event/cancel path. Unix scanner tests remain source-broken |
| F09 environment graphs | Incomplete with regression; P1 open | Path markers can now request nonbuiltin environment IDs | Ingest writes instance before environment; graph IDs collide by project basename/single kind; persisted kind detected is outside enum, roots/edges lost; queries/duplicates remain tuples; no corrections/restart graph loading |
| F10 resolver eligibility/version | Partially repaired; P1 open | Blocked-only no longer selected; invalid OR grammar returns error; rc1 fails stable >=3.13; 0.9 fails ^0.2 | Wire discards all preferences and invents x86_64; no architecture/scope filtering; rejected alternatives/reasons lost; malformed text/exact prerelease/zero-zero caret still wrong |

## Concrete remaining defects and executed proof

### D2-01 [P1] First-scan environment FK failure is hidden as success

**Sources:** `apps/daemon/src/service.rs:912-926`; `crates/registry/src/migrations/001_init.sql:31`; `crates/environment/src/lib.rs:88-112`.

The instance is upserted before its newly detected environment is inserted. `upsert_instance().is_ok()` drops the error; the later environment INSERT ignores the real Environment and writes kind `detected`, root/parent NULL. Interface FK failure is also ignored. In a fresh real daemon scan with two owned `.venv` roots, tenant-a's Python was absent on scan1 while tenant-b sharing the same environment ID appeared after the environment insertion; scan2 added tenant-a. Both responses and sessions said completed/no errors. The fixture environment row was `(env.project.same,detected,NULL,NULL)`.

**Acceptance:** transact environment and dependent instance/interface/evidence writes in FK order using validated authoritative records; propagate failure and record partial/failed scan status. A first scan of two new distinct environments must register both completely without requiring a retry. Persist correct kind/root/edges. Inject environment/interface/instance failures and verify no completed false success/partial dangling state.

### D2-02 [P1] Legacy IDs, canonical aliases and returned identity diverge

**Sources:** `crates/registry/src/repo.rs:53-62`; `apps/daemon/src/service.rs:913,923,939-940`; `crates/recognizer/src/lib.rs:261,290-293`; `crates/core/src/path_norm.rs:8-26`.

Upsert preserves an existing ID from its path lookup, but its result is `()`; ingestion records the newly generated path-hash ID in seen and creates an interface under that new ID. With a seeded R1-style ID at a currently scanned fixture path, last_seen updated but the retained row became Missing and got no interface. This is an upgrade regression, not failure to find the file. Canonical_path is never used for identity: scanning one owned Python fixture via normal Windows path then equivalent `\\?\` path produced two IDs with identical canonical_path; original row Missing, alias Available, file still existed.

**Acceptance:** return the authoritative persisted identity from upsert and use it for seen/placements/interfaces/evidence. Define canonical/link identity policy, account for Windows extended/normal/case/relative aliases and preserve display/link observations separately from distinct installed copies. Regression must start with an R1-style database and verify ID, interfaces, corrections and Available status survive rescans, plus alias and genuinely separate-copy cases.

### D2-03 [P1] Missing reconciliation is global and persistence failures invalidate live tools

**Sources:** `crates/registry/src/repo.rs:484-503`; `apps/daemon/src/service.rs:155,162,912,939-945`.

`mark_missing_except` enumerates every Available row rather than rows covered by this scan's successful roots/provider scope. A harmless owned Python file outside current visited roots was seeded Available; Quick scan marked it Missing while `exists=true`. Quick now skips package roots, so this also threatens Full-only discoveries. No persisted root association/continuation exists.

An owned SQLite trigger injected an evidence INSERT failure for instance ingestion. Real scan returned success/roots_failed=[] and persisted status completed/errors=[]; recognized currently scanned fixture rows became Missing because failed upserts were excluded from seen. `finish_scan` and invalidation errors are discarded. One instance transaction is insufficient for coherent scan reconciliation.

**Acceptance:** reconcile only authoritative successfully covered provider/root sets, preserving failed/truncated/unvisited uncertainty; perform coherent transactional ingestion/reconciliation and report write errors. Quick must preserve existing Full-only/unvisited installations. Test complete deletion, changed PATH, failed/partial root, capped scan, injected write failure, interruption and concurrent scan/restart. No live instance may become Missing because its write failed.

### D2-04 [P1] Rescan overwrites user trust and ownership decisions

**Sources:** `crates/registry/src/repo.rs:69-76`; `apps/daemon/src/service.rs:889,903-905`.

Upsert unconditionally replaces owner_json, trust_json and status from discovery. A fixture row seeded Blocked trust with user reason and corrected known owner was changed to Known/unknown-owner during successful rescan. No correction precedence or trust-transition validation exists. In the same legacy-ID probe it ended Missing because of D2-02; the overwrite itself is independent of that ID defect and is directly visible in stored JSON.

**Acceptance:** keep observations distinct from durable user decisions; scans cannot silently unblock/downgrade decisions or discard correction evidence. Test stable-current and legacy IDs, user Blocked/UserTrusted/ownership corrections, changed binary requiring revalidation, and restart. Apply documented transition authority rather than confidence-based overwrite.

### D2-05 [P1] Path confidence is still used as execution trust

**Sources:** `crates/recognizer/src/lib.rs:164-178,221-235,263-265`; Python rule `:37-38`.

Corroboration is defined solely as any evidence confidence>=0.85, but the recognizer creates PathPattern confidence0.9 for name+path. The candidate path includes the filename; `python.exe` therefore already matches substring python. Real plain/bin/python.exe containing only harmless text became Known/Available with sole path_pattern evidence0.9. There is no read of candidate metadata, publisher, signature, hash or package content. Numerical recognition confidence still grants trust despite the code comment asserting otherwise.

**Acceptance:** weak path/basename patterns remain untrusted hypotheses; independent verifiable evidence/provenance supports tool identity and execution trust. The renamed/path-shaped marker executable must never run in discovery or gain Known solely from text naming. Do not claim default unauthorized execution from this probe: no execute call was made and default tool policy is Ask. Genuine native tools must acquire accurately measured metadata through actual implemented paths rather than compiled naming constants.

### D2-06 [P2] Candidate dedupe is case-sensitive and metadata is still lost

**Sources:** `crates/registry/src/repo.rs:235-244`; `crates/registry/src/models.rs:17-23`; `apps/daemon/src/service.rs:931-936`; `crates/scanner/src/lib.rs:70-74`.

Exact-text repeat works, but SELECT compares raw path only and no unique normalized constraint exists. Two real scans of the same Windows mystery.exe using ordinary and uppercase PATH spelling yielded two different candidate UUIDs; total unknown count396->397. Both rows had canonical_path=NULL,size_bytes=NULL,metadata_json='{}'. Native Registry metadata was likewise discarded: after five scans the number of nonempty candidate metadata rows was zero. Candidate observation timestamps are not refreshed and no stale/promotion reconciliation exists. Concurrent query-then-insert remains unprotected against duplicates.

**Acceptance:** atomic normalized/canonical candidate identity, retained source/metadata/canonical/size/version/evidence, refreshing detection state and scoped disappearance/promotion. Test casing/separators/link aliases, concurrent same-path insertion, unknown-to-recognized promotion and multiple distinct candidates. Discovery inspection must expose useful preserved provenance, including Registry/package/bundle metadata.

### D2-07 [P1] Environment identities collide and real graph data is not persisted/exposed

**Sources:** `crates/environment/src/lib.rs:59-72,107-108,119-125`; `apps/daemon/src/service.rs:216-222,915-919`; `crates/registry/src/repo.rs:593-603,642-650`; service open env_graph initialization.

Project environment IDs use only the directory immediately before .venv, not its full root. Owned tenant-a/same/.venv and tenant-b/same/.venv both became env.project.same. Conda and agent paths each collapse to one global ID; kind associations are unsupported facts from substrings. In-memory root is an executable path, parent is always None; persisted rows discard both and use invalid kind detected. No persisted environment graph is reloaded. Actual API returned `(id,name,kind)` tuples and duplicates `(Python,4)`, with no instance placements/version/arch/owner/evidence/size/use/detection data.

**Acceptance:** distinct stable canonical environment-root identity and marker/metadata evidence; coherent parent edges/context for venv/Conda/package/project/application/WSL-container/agent installs. Preserve corrections and uncertainty across restart. Full query contracts must carry graph and complete duplicate instances required by B02. Same project basename in different locations, multiple Conda envs and multiple agents must not merge.

### D2-08 [P1] Real resolve requests ignore cwd/environment/trust/architecture

**Sources:** `apps/daemon/src/service.rs:242-264`; `crates/registry/src/models.rs:5-14`; `crates/resolver/src/lib.rs:29-35,59-70,98-109,129-138`.

Daemon assigns arch=x86_64 to every row and always calls default prefs. With two seeded Known providers, requested cwd/project-b + prefer_environment=env.project.b + arch=x86_64 + require_trust=verified selected project-a's aarch64 Known provider, reported as x86_64 with cwd_match=false. The library trust preference added in R2 is unreachable through the wire. No architecture or scope eligibility model is implemented. Blocked-only now yields selected:null (positive), but reports error:null, drops blocked alternative and cannot explain structured rejection.

**Acceptance:** authoritative metadata must flow to candidates; validate/map wire preferences and apply architecture/scope/trust/environment/cwd eligibility before ranking. Return excluded candidates/reasons and explicit Missing/Blocked/Unavailable results. Test real daemon two-project conflict, architecture and minimum trust, scope, aliases, unavailable changes and malformed preferences.

### D2-09 [P2] Version repairs cover individual examples but grammar/equality remain wrong

**Sources:** `crates/core/src/version.rs:54-65,73,80,93-94,111-114`; `crates/resolver/src/lib.rs:78-95`.

Positive executed controls: OR constraint now gives an error; prerelease rc1 no longer matches stable >=3.13; 0.9 no longer matches ^0.2. Remaining executed failures: `>=banana` is accepted and selects3.13.0; `=3.13.0` and `=3.13.0-rc2` both select3.13.0-rc1; ^0.0.3 selects0.0.9. Non-numeric components are still dropped, exact equality bypasses the prerelease guard, and zero-major caret checks only the minor. There are no added version tests for the claimed changes.

**Acceptance:** define actual supported version grammar and reject malformed components; implement consistent comparison/equality/prerelease/build and zero-major boundaries. Use an established parser or complete explicit semantics with fixtures. Exercise those fixtures through daemon and required/optional skill resolution; no malformed constraint can become unrestricted selection.

## Broad original-target gaps — not bounded final-review corrections

| Original target | Actual R2 source/evidence | Still required |
| --- | --- | --- |
| B01-01/05 canonical model/persistence | Raw string DTOs, unchanged migration1, generic synthetic evidence .8 at repo:102-104; definition vendor/category/description still NULL/[] at :45-46 | Validate writes/relationships/provenance, true observations and corrections; forward-version refusal, backup/recovery, interrupted/concurrent writes. Probe added schema version999; reopening daemon ping still succeeded |
| B01-02 schemas/resources | Four small schemas now committed; no source/runtime references or schema validation library/fixtures; resources directory and resource loader absent. Tool schema only definition; no model compatibility version. Capability schema allows underscores that canonical validator rejects | Enforced versioned schemas with valid/invalid conformance fixtures, authoritative Rust/client consistency, independently versioned recognition/capability resource packages with malformed/incompatible/atomic update behavior |
| B01-06 modes/incremental | Quick skips package manager at scanner/lib:47-50; all calls still rescan; scan_sessions store only counts at service:156-170. cancelled field never set; no watchers/debounce/event/cancel methods | Meaningful root-scoped incremental refresh/invalidation, bounded events/watch/debounce/cancel/deadlines, persisted roots/coverage and explicit partial status |
| B01-07 actual Windows/macOS metadata | AppPaths/Uninstall reads now real at providers:176-255 (positive); metadata only name/display/install_location, all errors/caps flattened. Package provider still bounded depth2 at :144-166. Mac provider unchanged four folders and bundle=true at :318-353 | Package metadata/normal Cellar depth, winget/Scoop/choco, VS/SDK/WSL/Docker/agent/environment roots; macOS bundle/LaunchServices/MacPorts/Xcode/CLT/framework/user bundles; realistic portable fixtures and honest provider/root coverage |
| B01-08 recognition | Rules remain compiled constants, metadata never consumed, version_hint never populated, arch=host at recognizer:263-265; GCC/MSVC still org.llvm.clang, no .NET/configured-agent rules. Probe observed5 instances/0 versions | Representative measured metadata/version/architecture/evidence fixtures and real native recognition, compatible resource loading and properly bounded known probes where used |
| B01-09 graphs/duplicates | New path tags, but root/parent/provenance discarded and project names collide, abbreviated query results | Full coherent typed graph and duplicate placements/times/size/owner provenance/corrections |
| B01-10 context eligibility | Some filtering helpers improved; wire still default preferences and false arch | Real request context/preferences/scope/architecture/trust and explicit rejected alternatives/results |
| B01-13 import/report | Method enum ends ExportReport (`protocol/methods.rs:30,59`); no import method/CLI/implementation. Export at service:859-876 still omits environments and required tool metadata defined in protocol DTO | Versioned validated report/manifest import with provenance and foreign-path unavailable/untrusted handling; compatible useful redacted report |
| B01-17 cross-platform tests | scanner/lib:110-114 still defines evil only cfg(windows), then uses it unconditionally; :95-101 writes executable fixture without Unix executable permissions. Native/recognizer/env/resolver tests remain narrow original helper tests | Repair Unix test compilation/permissions and commit representative portable native/metadata/integration/platform checks. These are source defects; unavailable macOS host remains a separate unverified check |

Windows Registry coverage specifically still returns successful empty/partial results on open/enumeration failure, uses flatten/take200/300, and lacks per-hive outcomes; filesystem providers still return Ok for missing roots, filter Python* through literal exists, and flatten/take subtrees (providers:28-29,85,196,233,290-305). In canonical-identity probe we deliberately provided absent owned filesystem roots; scan still returned roots_failed=[] and roots_ok6. A success counter cannot establish complete coverage or authorize global invalidation.

Uninstall candidate paths may be directories or registry URIs (providers:238-248) and are passed unchanged to basename-only recognition; InstallLocation matching a known name can be treated as an Available CLI instance despite not being an executable. No executable-validation/type interface check prevents that source path. Not executed as a host defect here.

## Correction scope for parent

Returning the persisted ID, ordering environment insertion, propagating write errors, mapping existing resolver prefs/arch, repairing Unix fixture cfg and rejecting obvious invalid versions could be localized. Completing root/provenance tracking and coherent scan transactions, actual recognition trust/metadata/resources, full environment graph/native providers/incremental machinery/schema enforcement/import/recovery are substantial unresolved B01 implementation work. Closing one bounded line defect cannot close F06-F10 or the full original matrix. No large missing subsystem should be silently reclassified as host-unverified or moved to B02 during R2.

## Reproductions and boundaries

- `data_runtime_probe.py` -> `run-9e2872cc/results.json`: first environment insertion, repeated refresh/count positives, legacy ID and correction overwrite, outside-root invalidation, trigger failure false success, candidate metadata and schema999 reopen. Owned fixtures only; direct SQLite modifications intentionally create controlled state/failure conditions.
- `resolver_runtime_probe.py` -> `resolver-917310f4/results.json`: seeded constraint/preference/trust/architecture scenarios; actual daemon results, no execution.
- `candidate_case_probe.py` -> `candidate-6d728f65/results.json`: same existing file with case-only PATH spelling; duplicate candidate UUIDs.
- `canonical_identity_probe.py` -> `identity-976cffc6/results.json`: same existing file with equivalent normal/extended Windows path; two IDs/identical canonical_path.

Parent-verified release executable was used by absolute path; no changes to machine/user PATH. Only child process environments were altered. Source-only claims above are identified separately from executed Windows observations and unavailable macOS host verification. Final checkout check retains HEAD7a1ba39; service.rs and repo.rs are modified by the parent's separately announced bounded policy corrections. This agent made no checkout edits. All source anchors and binary probe results in this report refer to the immutable original7a revision, before those parent edits; the parent states native/resolver/data logic is unchanged. No further broad tests were run after that instruction.
