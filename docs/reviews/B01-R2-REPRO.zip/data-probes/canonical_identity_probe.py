import pathlib, os, sqlite3, subprocess, json, uuid, sys
sys.stdout.reconfigure(encoding='utf-8')
base=pathlib.Path(__file__).parent/('identity-'+uuid.uuid4().hex[:8])
root=base/'fixture'
root.mkdir(parents=True)
(root/'python.exe').write_bytes(b'harmless python-named metadata fixture')
db=base/'registry.sqlite'
env=os.environ.copy()
env.update({'TOOLHUB_REGISTRY':str(db),'ProgramFiles':str(base/'absent-pf'),'ProgramFiles(x86)':str(base/'absent-pf86'),'LOCALAPPDATA':str(base/'absent-appdata')})
exe=os.environ['R2_TOOLHUBD']
scans=[]
for n,spelling in enumerate((str(root),'\\\\?\\'+str(root)),1):
    env['PATH']=spelling
    req=json.dumps({'jsonrpc':'2.0','id':n,'method':'scan.start','params':{'mode':'quick'}})+'\n'
    p=subprocess.run([exe],input=req,env=env,text=True,encoding='utf-8',capture_output=True,timeout=30)
    scans.append(json.loads(p.stdout))
conn=sqlite3.connect(db)
rows=conn.execute('SELECT id,path,canonical_path,status FROM tool_instances WHERE path LIKE ?',('%'+base.name+'%',)).fetchall()
out={'scans':scans,'fixture_instances':rows,'same_existing_file':(root/'python.exe').is_file(),'artifacts':str(base)}
result=json.dumps(out,ensure_ascii=False,indent=2)
(base/'results.json').write_text(result,encoding='utf-8')
print(result)
