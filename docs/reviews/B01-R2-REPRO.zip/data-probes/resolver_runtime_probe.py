import pathlib, os, sqlite3, subprocess, json, uuid, sys
sys.stdout.reconfigure(encoding='utf-8')
base=pathlib.Path(__file__).parent/('resolver-'+uuid.uuid4().hex[:8])
base.mkdir()
db=base/'registry.sqlite'
env=os.environ.copy()
env['TOOLHUB_REGISTRY']=str(db)
exe=os.environ['R2_TOOLHUBD']
seq=0
def call(params):
    global seq
    seq+=1
    method='ping' if not params else 'resolve.capability'
    req=json.dumps({'jsonrpc':'2.0','id':seq,'method':method,'params':params})+'\n'
    p=subprocess.run([exe],input=req,env=env,capture_output=True,text=True,encoding='utf-8',timeout=15)
    return json.loads(p.stdout)
call({})
conn=sqlite3.connect(db)
conn.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES ('org.python.python','Python','t','t')")
conn.execute("INSERT INTO tool_capabilities VALUES ('org.python.python','language.python.execute')")
for eid in ('env.project.a','env.project.b'):
    conn.execute('INSERT INTO environments(id,name,kind) VALUES (?,?,?)',(eid,eid,'venv'))
stmt='''INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,environment_id,trust_json,status,first_seen,last_seen)
VALUES (?,'org.python.python',?,'windows',?,?,?,?, 'available','t','t')'''
conn.execute(stmt,('a-python','3.13.0','aarch64','C:/fixture/project-a/python.exe','env.project.a','{"level":"known"}'))
conn.execute(stmt,('b-python','3.13.0','x86_64','C:/fixture/project-b/python.exe','env.project.b','{"level":"verified"}'))
conn.commit()
def resolve(**params):
    return call({'capability':'language.python.execute',**params})
out={'artifacts':str(base)}
out['project_b_request']=resolve(cwd='C:/fixture/project-b',prefer_environment='env.project.b',arch='x86_64')
out['verified_request']=resolve(require_trust='verified')
conn.execute("UPDATE tool_instances SET trust_json='{"+'"level":"known"'+"}' WHERE id='b-python'")
conn.commit()
out['project_b_equal_trust']=resolve(cwd='C:/fixture/project-b',prefer_environment='env.project.b',arch='x86_64',require_trust='verified')
conn.execute("DELETE FROM tool_instances WHERE id='b-python'")
conn.execute("UPDATE tool_instances SET trust_json='{"+'"level":"blocked"'+"}'")
conn.commit()
out['blocked_only']=resolve()
conn.execute("UPDATE tool_instances SET trust_json='{"+'"level":"known"'+"}',version='3.13.0'")
conn.commit()
out['invalid_or']=resolve(version='>=3.13 || true')
out['invalid_text']=resolve(version='>=banana')
conn.execute("UPDATE tool_instances SET version='3.13.0-rc1'")
conn.commit()
out['stable_min_prerelease']=resolve(version='>=3.13.0')
out['stable_exact_prerelease']=resolve(version='=3.13.0')
out['different_prerelease_exact']=resolve(version='=3.13.0-rc2')
conn.execute("UPDATE tool_instances SET version='0.9.0'")
conn.commit()
out['caret_0_2']=resolve(version='^0.2.0')
conn.execute("UPDATE tool_instances SET version='0.0.9'")
conn.commit()
out['caret_0_0_3']=resolve(version='^0.0.3')
result=json.dumps(out,ensure_ascii=False,indent=2)
(base/'results.json').write_text(result,encoding='utf-8')
print(result)
