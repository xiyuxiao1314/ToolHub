import pathlib, os, sqlite3, subprocess, json, uuid, sys
sys.stdout.reconfigure(encoding='utf-8')
base=pathlib.Path(__file__).parent/('candidate-'+uuid.uuid4().hex[:8])
root=base/'fixture'
root.mkdir(parents=True)
(root/'mystery.exe').write_bytes(b'harmless candidate metadata')
db=base/'registry.sqlite'
env=os.environ.copy()
env.update({'TOOLHUB_REGISTRY':str(db),'ProgramFiles':str(root),'ProgramFiles(x86)':str(root),'LOCALAPPDATA':str(root)})
exe=os.environ['R2_TOOLHUBD']
results=[]
for n, spelling in enumerate((str(root),str(root).upper()),1):
    env['PATH']=spelling
    req=json.dumps({'jsonrpc':'2.0','id':n,'method':'scan.start','params':{'mode':'quick'}})+'\n'
    p=subprocess.run([exe],input=req,env=env,text=True,encoding='utf-8',capture_output=True,timeout=30)
    results.append(json.loads(p.stdout))
conn=sqlite3.connect(db)
rows=conn.execute('SELECT id,path,canonical_path,size_bytes,metadata_json FROM scan_candidates WHERE lower(path) LIKE ?',('%'+base.name+'%',)).fetchall()
out={'scans':results,'same_existing_file':(root/'mystery.exe').is_file(),'fixture_candidate_rows':rows,'artifacts':str(base)}
result=json.dumps(out,ensure_ascii=False,indent=2)
(base/'results.json').write_text(result,encoding='utf-8')
print(result)
