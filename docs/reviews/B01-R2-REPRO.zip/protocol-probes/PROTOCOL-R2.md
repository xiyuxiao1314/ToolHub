# B01 R2 — protocol, clients, sessions, skills and adapters

Internal domain evidence for **one consolidated formal R2**, not an additional review round. No acceptance decision is implied. F11–F18 remain incomplete as groups: F11/F16 open; F12/F13/F14/F15/F17/F18 partial. Several important individual repairs are confirmed below, but structural required source gaps are not external host/account verification gaps.

## Revision and verification boundary

- Authoritative reviewed checkout: `C:\Users\hp\OneDrive\文档\ChatGPT\押品后端\.toolhub-workbench\r2\checkout`.
- Actual bundle HEAD: `7a1ba39a8fb27dddffb4eb662a973c8bedf287ed`, independently read with `git rev-parse HEAD`; working tree was clean.
- Original R1 base: `46a06aa11c370b2ca4432909aa2b8b0a70127090`.
- Read AGENTS.md, original task/repair brief and F11–F18 acceptance in `D:\ToolHub\docs\reviews\B01-R1-FINDINGS.md`, delivered repair map/coverage/runbook and assigned source paths.
- Parent reported exact-HEAD fmt/test/Clippy/release-build exit 0. **This reviewer did not run Cargo** and does not treat passing workspace checks as closure of these findings.
- Executed parent-built release binaries at `C:\Users\hp\AppData\Local\Temp\toolhub-codex-r2-7a1ba39-target\release` using the private `probe_protocol.py` harness. Invocation completed exit 0 in approximately 1.4 seconds, collecting 52 observations in `PROTOCOL-PROBES.json`. Harness input/output reads have bounded waits; processes are closed/killed at completion.
- Private fixture database and harmless records were created only below this report's directory. One child invocation executes the built ToolHub CLI with an invalid subcommand to obtain a safe exit-2 result. No installed unknown software was executed, no application/user configuration changed, and no installation/cloud/workbench action occurred.
- `SMOKE-NEGATIVE.json` records a separate private copy of the exact submitted smoke script with a `toolhub.cmd` control returning 9 for all commands; script exits 1. No checkout files changed.
- Runtime observations below are marked **Executed**. Other claims are **Static** source findings. Unix compilation and Windows pipe runtime are parent-owned/unverified by this reviewer.
- All source anchors are relative to the authoritative checkout, one-based at the actual bundle HEAD.

## F11 — OPEN: required shared service remains absent from clients

**Static sources:** `apps/cli/src/main.rs:292`–`:300`, `:318`; `apps/daemon/src/main.rs:67`–`:83`, `:92`–`:101`; `crates/ipc/src/lib.rs:96`, `:103`, `:120`, `:124`, `:135`.

The CLI still always spawns a private stdio daemon. There is no call to `connect_named_pipe`, existing-service discovery/readiness/reconnect, startup/request deadline or single-instance ownership. A library function named connect_named_pipe is not an integrated client path. Shared durable database records cannot establish one live service.

The new Windows listener creates a pipe, starts a reader thread and immediately creates another instance. It never calls ConnectNamedPipe, and CreateNamedPipe sets maximum instances to 1. It passes null security attributes and has no caller credential/DACL enforcement. Parent owns runtime confirmation of listener lifetime. The official [ConnectNamedPipe documentation](https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-connectnamedpipe) describes the server connection lifecycle and already-connected race handling; no equivalent accept step exists here.

The original Unix unqualified write_frame defect is repaired (`daemon/main.rs:114`), but a new deterministic Unix compilation defect is introduced: `if cfg!(windows)` at line 67 leaves the Windows branch compiled/typechecked on Unix, while user_scoped_pipe_name/create_named_pipe called at lines 68/71 only exist under #[cfg(windows)] in ipc. This is static source evidence, not a claimed macOS build execution. The global `/tmp/toolhubd.sock` still exists (`ipc:91`) and is unconditionally removed at daemon line 98 even if another daemon is live. Setting permissions afterward does not implement peer identity or ownership protection.

**Closure criteria:** actual CLI/MCP connections to one authenticated user-scoped daemon; readiness/startup/reconnect bounds; safe endpoint/single-instance lifecycle; concurrent query/scan/exec/cancel; Unix target compilation and honest platform evidence. This is substantial missing integration, not an unverified multi-client soak of complete source.

## F12 — PARTIAL: envelope checks added, limits/types/schemas remain disconnected

**Confirmed repairs, Executed:** jsonrpc="1.0" produces invalid_request; object-valued ID is rejected. Four schema files now exist (Static).

**Executed residuals:**

- Scalar params 7 on ping succeeds (`scalar_params`).
- ID-less ping receives `{id:null,result:...}` (`notification_reply`).
- A 1,048,646-byte stdio request succeeds (`oversize_reply`).
- Well-formed `{}` produces parse_error -32700 rather than invalid_request (`wellformed_invalid_request`).
- Rejected object ID is echoed as an object in the response (`invalid_id`), leaving the error envelope invalid.
- Actual resolve result emits `canonical` and no score; search emits instance rows; export omits environments and per-tool capabilities (`resolve_actual`, `search_actual`, `report_actual`).

**Static sources:** daemon/main.rs:43–55 uses unbounded lines and conflates deserialization/parse errors. service.rs:89–105 validates only version/ID and does not suppress notifications or validate params; line 98 preserves the invalid ID. service.rs:191/265/872 constructs ad hoc results. `crates/protocol/src/types.rs:16` requires grouped instance_count/capabilities; line 27 requires canonical_capability; line 42 requires score; lines 84/94 require environments/tool capabilities. Declared result DTOs remain unchanged and unused by the service. No Cargo deserialization probe was performed; required fields are demonstrably absent from real results.

`schemas/protocol.schema.json:10` allows arbitrary params with `{}`; there are no method/result/error/event/negotiation schemas or valid/invalid conformance fixtures. Schema files are not loaded/enforced by daemon or skill registration. EventEnvelope and service seq remain unused; method enum has no negotiation/cancel/subscription operation. Global mutex holds synchronous service calls (`daemon/main.rs:50`, `:77`, `:112`). These are required B01-03/F12 source gaps, not desktop features.

**Closure criteria:** bounded framing on supported transport, notification/error conformance, authoritative typed request/result/error models, version compatibility, method schemas plus fixtures, real cancellation/events/backpressure and integrated conformance tests.

## F13 — PARTIAL: successful MCP path improved, error/lifecycle conformance still fails

**Confirmed repairs, Executed:** initialize now advertises tools capability; notifications/initialized emits no reply; tools/list has a tools object; tools/call success has content items; not-found tool call no longer kills the gateway and a following search succeeds. (`mcp_initialized_notification`, `mcp_tools_list`, `mcp_error_then_success`).

**Executed residuals:**

- Initialize with unsupported protocolVersion 2099-01-01 advertises that value back (`mcp_unsupported_version`); no supported-version negotiation exists.
- Missing instance returns error.message as an **object** containing content/isError (`mcp_missing_error`), violating JSON-RPC's string message type.
- Search input query=42 is silently converted to empty search and succeeds with all fixture rows (`mcp_invalid_input`).
- jsonrpc="1.0", object ID and >1-MiB MCP requests are accepted (`mcp_invalid_jsonrpc`, `mcp_invalid_id`, `mcp_oversize_reply`).
- Malformed JSON `{` produces a non-JSON-RPC `{ok:false,error:...}` and exits the gateway 1 (`mcp_parse_error`, `mcp_process_after_parse_error`); subsequent service is unavailable.

**Static sources:** CLI main.rs:385/390 unbounded lines and fatal parser; :403 simply echoes requested version; :432 defaults wrong query types; :481–498 wraps tool errors in error.message object; :415–421 duplicates the MCP schemas. The MCP crate's validator/spec helpers remain unused and their validator itself fails strict type/required-field checking. No actual initialized-state or cancellation handling is implemented; notifications/cancelled is discarded at :409.

**Closure criteria:** supported-version/state handling, correct protocol vs tool error envelopes with string error messages, strict input validation, bounded parse/recovery and following-success tests. These requirements follow the advertised version's [MCP lifecycle](https://modelcontextprotocol.io/specification/2024-11-05/basic/lifecycle) and [MCP tools](https://modelcontextprotocol.io/specification/2024-11-05/server/tools) contracts.

## F14 — PARTIAL: classifications persist, session/candidate authority remains unenforced

**Confirmed repairs, Executed:** missing candidate_id is rejected; nonempty classification is written to SQLite evidence and remains visible through a separate SQLite connection (`empty_classification`, `persisted_classifications`). Evidence does not promote executable trust.

**Executed residuals:**

- A candidate.list-only session is issued but cannot inspect/list candidates (`candidate_list_only_inspect`). discovery.list instead exposes session IDs.
- A second daemon launched with TOOLHUB_PRINCIPAL=probe.other can enumerate, inspect, classify and revoke the first principal's session (`foreign_principal_*`).
- First daemon subsequently accepts classification after the second daemon revokes the session (`revoked_owner_memory_classify`).
- Classifying nonexistent.candidate succeeds and persists a phantom candidate evidence row. Confidence 2 is silently clamped to 1 (`unknown_candidate_classification`, `persisted_classifications`).
- CLI discovery classify is still absent (exit 2), although launch instructions name it (`cli_command_discovery_classify`).

**Static sources:** service.rs:630–658 issues sessions to request-controlled agent_id, ignoring peer_principal; :667–683 exposes all IDs; :685–706 returns every candidate for a session rather than scoped candidate metadata; :708–745 checks only memory session/scopes plus nonempty label/ID; repo.rs:543 inserts evidence without candidate foreign-key/membership validation; :754–765 revokes without owner checks and ignores write failure; sessions only load at open (:40). `DiscoverySession` lacks principal or candidate-set binding (`agent-bridge/lib.rs:24`). known_probe.version scope has no executable RPC operation.

**Closure criteria:** authenticated caller-bound credentials, candidate membership/data scopes, individual list/inspect/metadata/probe/classify operations, authoritative cross-client revocation/expiry, rejection of unsolicited/bad confidence/payload and queryable durable provenance. Persistence alone does not close F14.

## F15 — PARTIAL: raw registration/query added but parser/safety/availability bypassed

**Confirmed repairs, Executed:** skill.list register writes a record; inspect/resolve reads it; explicit hooks and unsupported schema v999 are rejected (`persisted_skills_count`, `skill_hooks_rejection`, `skill_schema_rejection`).

**Executed residuals:**

- Manifest kind=bogus, instruction_file="../outside/SKILL.md", requires="wrong-type" and package_path all register. Inspect reports available with empty requirements (`skill_unsafe_register`, `skill_unsafe_inspect`).
- Requirement >=999 is satisfied by only version-1.0 providers (`skill_version_inspect`). Optional constraints are absent from the result.
- A capability supplied only by a Blocked-trust instance is available (`skill_blocked_inspect`).
- No CLI skill register command exists (`cli_command_skill_register`).

**Static sources:** service.rs:542–574 checks only ID/schema/hooks/install then raw upserts; it never calls SkillManifest parsing/path validation. :594–610 checks only whether any registry capability providers exist, not versions/trust/path eligibility; optional requirements are ignored. :627 returns malformed for an unknown ID rather than a structured not-found contract.

`core/skill.rs`, `skills/src/lib.rs` are unchanged from R1: prefix schema acceptance at core:72, non-array requirements ignored at :78/84, forced Instruction at :100, discarded package_path at :109, Windows absolute/UNC/root containment defects at :119. The unused availability helper still uses suffix/first-provider matches (skills:22) and ignores optional versions (:54–57). load_skill_dir only reads skill.json and never parses SKILL.md/MCP/package content (:78–91); no path containment/symlink resolver or declarative package import pipeline is wired.

**Closure criteria:** one authoritative safe manifest parser/registration boundary, all three kinds and file containment, required/optional versions/aliases and trust eligibility via authoritative resolver, real shared CLI/MCP registration/query/resolve with no executable hooks. This is substantial missing implementation, not an external prerequisite.

## F16 — OPEN for launch; partial fixed config presentation only

**Static sources:** `crates/agent-bridge/src/adapters.rs:17`–`:34`, `:127`; `agent-bridge/lib.rs:85`–`:87`; `apps/daemon/src/service.rs:767`–`:792`.

Agent trait still generates JSON via string interpolation, detects command names, returns manual-launch text and has no agent-specific supported session process launch/cancel. service agent.list now emits a typed **fixed** MCP configuration (a useful limited repair), but endpoint="toolhub" is constant and TOOLHUB_ENDPOINT is never read by the CLI. Its launch field is just discovery_task_prompt with placeholder <session>. Generic CLI/MCP/OpenCode/Codex/Claude configuration/health/launch contracts are not completed. Instructions still name nonexistent classify CLI.

Real account access can block host verification of an implemented launcher. It cannot explain an absent launcher or unchanged unsafe generic config generator. No login/installation was attempted by this reviewer.

**Closure criteria:** typed adapter-specific configuration, actual bounded supported launch/cancel and credentials/scopes integrated with F14, or accurately classify missing source as not-implemented while recording actual external access blockers separately.

## F17 — PARTIAL: JSON missing-instance error repaired; exit/activity/report/import still incomplete

**Confirmed repair, Executed:** CLI --json inspect missing gives parseable {ok:false,error:...} with exit 3 (`cli_missing`); reusable DaemonClient no longer exits internally.

**Executed residuals:** harmless approved child CLI returns exit_code=2/status=failed while outer toolhub --json exec exits **0** (`cli_child_failure`). SQLite has one execution row but activity.list returns [] (`activity_after_execution`, `persisted_execution_count`). Report lacks environments/per-tool capabilities (`report_actual`). import.report is method_not_found; CLI import/activity do not exist (`import_method`, `cli_command_import`, `cli_command_activity`).

**Static sources:** CLI :144–155 determines codes by arbitrary message substring, not typed error codes; :276–281 prints execution failure results and returns success. Spawn/timeout/readiness failures remain generic/unbounded (:300/:318). service :425 writes execution_records but no activity; :851 reads only separate activity rows; :859–876 emits the old report shape; methods and CLI enums have no import/activity command. No validated report/manifest compatibility/provenance/foreign-path import exists.

**Closure criteria:** stable typed error/exit semantics including execution statuses and parse errors; actual execution/denial activity with redaction; authoritative useful report and transactionally validated import ensuring foreign paths stay unavailable/untrusted. Activity table query alone does not supply execution activity.

## F18 — PARTIAL: native failure control now fails; important assertions still vacuous/missing

**Confirmed repair, Executed:** copied exact smoke script with all native commands forced to exit 9 exits 1 at first status command, not SMOKE DONE. `SMOKE-NEGATIVE.json` records this private control. Invoke-Toolhub :10–16 checks native status.

**Static residuals:**

- scripts/smoke.ps1:31–36 calls a text file unknown-tool-xyz.exe a marker-producing executable. It is not a runnable Windows executable; its text only echoes if a marker already exists, rather than creating one. Its directory is not added to PATH/scan roots and line 43 scans the native roots. The no-marker assertion at :58 remains vacuous.
- Policy deny step only calls policy.get (:62); MCP step only mcp tools (:76), not a live client. No skill/discovery authority/protocol cancellation/concurrency/redaction-negative regression is committed.
- Approved-exec assertion checks only outer exit 0 (:95), which still occurs for child failure as directly reproduced under F17. It does not inspect status/exit_code/stdout; replay rejection alone does not establish safe execution success.
- No committed integration-test/portable conformance fixture tree or platform-check workflow was found. New schemas are not runtime-enforced and have no valid/invalid fixture suite.
- Repair map labels F11 source/F12 core/F14 core/F15 core closed and claims all F01–F18 acceptance completed; coverage still labels absent source as Implemented. Those claims exceed the observed implementation.

**Closure criteria:** runnable owned marker fixture actually discovered, semantic success/denial assertions, all required real daemon/client negative clusters and truthful original subtarget coverage. Passing the failing-command control is an important individual closure but does not close F18 as a group.

## Artifact HEAD mismatch (separate delivery finding)

Actual bundle HEAD is 7a1ba39. `docs/reviews/B01-R1-REPAIR-MAP.md:5` and `B01-R1-REPAIR-DELIVERY.md:5` still advertise 8715451 as final delivery HEAD (and leave an unclosed Markdown bold marker). git log shows later source repair 02f52d2 and docs child 7a1ba39. Use bundle HEAD for review and repair traceability; correct future manifests/reports rather than treating old stamped text as authority. Parent owns comparison to latest cloud artifact metadata.

## Reviewer correction scope

Bounded local corrections could address malformed MCP error envelopes, notification/error parsing, specific schema/DTO mismatch fields or exit-code mapping once integrated tests exist. They cannot implement the absent shared daemon/client lifecycle, caller/candidate authority model, complete declarative skill import or real adapters/report import as a last-minute reviewer rewrite. Do not mark those groups closed solely to fit the review budget.

## Reproduction artifacts

- `probe_protocol.py`: bounded real daemon/CLI/MCP reproduction; rerun with a fresh case directory automatically generated inside this directory.
- `PROTOCOL-PROBES.json`: 52 executed observations and persisted fixture database checks.
- `SMOKE-NEGATIVE.json`: native failure control output/exit.
- Private case SQLite database and smoke-negative copy/control remain beneath protocol-probes; they are not product source and contain synthetic records only.

Exact probe invocation used bundled existing Python and the parent-built exact-HEAD release directory. No Rust target compilation, schema validator installation, agent login or global IPC testing was performed by this domain reviewer.
