"""Bounded private R2 protocol/client probes. No checkout writes or Cargo calls."""
import json, os, pathlib, queue, sqlite3, subprocess, sys, threading, time, uuid

ROOT = pathlib.Path(__file__).resolve().parent
BIN = pathlib.Path(sys.argv[1])
CASE = ROOT / ('case-' + uuid.uuid4().hex[:10])
CASE.mkdir()
DB = CASE / 'registry.sqlite'
DAEMON = BIN / 'toolhubd.exe'
CLI = BIN / 'toolhub.exe'
BASE = dict(os.environ, TOOLHUB_REGISTRY=str(DB), TOOLHUBD_BIN=str(DAEMON))
OUT = {'head':'7a1ba39a8fb27dddffb4eb662a973c8bedf287ed','case':str(CASE),'observations':{}}

class Rpc:
    def __init__(self, command=None, principal='probe.owner', extra=None):
        env = dict(BASE, TOOLHUB_PRINCIPAL=principal)
        env.update(extra or {})
        self.p = subprocess.Popen(command or [str(DAEMON)], env=env, stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, encoding='utf-8', errors='replace')
        self.q = queue.Queue()
        self.err = []
        def read():
            for line in self.p.stdout:
                self.q.put(line.rstrip('\n'))
            self.q.put(None)
        def readerr():
            self.err.extend(self.p.stderr.readlines())
        threading.Thread(target=read, daemon=True).start()
        threading.Thread(target=readerr, daemon=True).start()
        self.seq = 0
    def raw(self, line, wait=3):
        self.p.stdin.write(line + '\n')
        self.p.stdin.flush()
        return self.read(wait)
    def read(self, wait=3):
        try:
            line = self.q.get(timeout=wait)
        except queue.Empty:
            return {'probe_timeout':wait}
        if line is None:
            return {'probe_eof': True, 'exit':self.p.poll()}
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            return {'probe_non_json':line[:500]}
    def call(self, method, params=None, **fields):
        self.seq += 1
        r = {'jsonrpc':'2.0','id':self.seq,'method':method,'params':params if params is not None else {}}
        r.update(fields)
        return self.raw(json.dumps(r, ensure_ascii=False))
    def stop(self):
        try:
            self.p.stdin.close()
            self.p.wait(timeout=2)
        except (OSError, subprocess.TimeoutExpired):
            self.p.kill()
            self.p.wait(timeout=2)

clients = []
try:
    a = Rpc(); clients.append(a)
    o = OUT['observations']
    o['initial_ping'] = a.call('ping')
    # Only owned fixture database writes, not application/user configuration.
    con = sqlite3.connect(DB)
    ts = '2026-09-29T00:00:00Z'
    con.execute('INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES (?,?,?,?)',
                ('org.fixture.safe','Safe CLI fixture',ts,ts))
    for iid, trust, path in [('safe.inst','known',str(CLI)),('blocked.inst','blocked',str(CASE/'blocked.exe'))]:
        con.execute('''INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,canonical_path,
                    trust_json,status,first_seen,last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                    (iid,'org.fixture.safe','1.0.0','windows','x86_64',path,path,
                     json.dumps({'level':trust}),'available',ts,ts))
    con.execute('INSERT INTO tool_capabilities(definition_id,capability_id) VALUES (?,?)',
                ('org.fixture.safe','language.python.execute'))
    con.execute('INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES (?,?,?,?)',
                ('org.fixture.blocked','Blocked provider',ts,ts))
    con.execute('''INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,canonical_path,
                trust_json,status,first_seen,last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                ('only.blocked','org.fixture.blocked','1.0.0','windows','x86_64',str(CASE/'only-blocked.exe'),
                 str(CASE/'only-blocked.exe'),json.dumps({'level':'blocked'}),'available',ts,ts))
    con.execute('INSERT INTO tool_capabilities(definition_id,capability_id) VALUES (?,?)',
                ('org.fixture.blocked','media.video.transcode'))
    con.execute('INSERT INTO scan_candidates(id,path,file_name,discovered_at) VALUES (?,?,?,?)',
                ('candidate.one',str(CASE/'unknown.exe'),'unknown.exe',ts))
    con.commit(); con.close()
    o['wrong_rpc_version'] = a.call('ping', jsonrpc='1.0')
    o['invalid_id'] = a.call('ping', id={'bad':True})
    o['scalar_params'] = a.call('ping', 7)
    o['notification_reply'] = a.raw(json.dumps({'jsonrpc':'2.0','method':'ping'}))
    big = json.dumps({'jsonrpc':'2.0','id':999,'method':'ping','params':{'pad':'x'*(1024*1024)}})
    o['oversize_bytes'] = len(big.encode())
    o['oversize_reply'] = a.raw(big)
    o['wellformed_invalid_request'] = a.raw('{}')
    o['resolve_actual'] = a.call('resolve.capability', {'capability':'language.python.execute'})
    o['search_actual'] = a.call('registry.search', {'query':'Safe CLI fixture'})
    o['report_actual'] = a.call('export.report')
    o['import_method'] = a.call('import.report', {'report':{'schema':'toolhub.report/v1'}})
    o['candidate_list_session'] = a.call('discovery.start', {'agent_id':'agent.owner','scopes':['candidate.list']})
    lsid = o['candidate_list_session']['result']['session_id']
    o['candidate_list_only_inspect'] = a.call('discovery.inspect', {'id':lsid})
    o['discovery_session'] = a.call('discovery.start', {'agent_id':'agent.owner','scopes':['candidate.inspect','classification.submit']})
    sid = o['discovery_session']['result']['session_id']
    o['empty_classification'] = a.call('discovery.classify', {'session_id':sid})
    o['unknown_candidate_classification'] = a.call('discovery.classify', {'session_id':sid,'candidate_id':'nonexistent.candidate','label':'phantom','confidence':2})
    b = Rpc(principal='probe.other'); clients.append(b)
    o['foreign_principal_list'] = b.call('discovery.list')
    o['foreign_principal_inspect'] = b.call('discovery.inspect', {'id':sid})
    o['foreign_principal_classify'] = b.call('discovery.classify', {'session_id':sid,'candidate_id':'candidate.one','label':'other-principal'})
    o['foreign_principal_revoke'] = b.call('discovery.revoke', {'session_id':sid})
    o['revoked_owner_memory_classify'] = a.call('discovery.classify', {'session_id':sid,'candidate_id':'candidate.one','label':'after-revocation'})
    o['skill_unsafe_register'] = a.call('skill.list', {'register':{'schema':'toolhub.skill/v1','id':'skill.unsafe','name':'Unsafe','kind':'bogus','instruction_file':'../outside/SKILL.md','requires':'wrong-type','package_path':str(CASE)}})
    o['skill_unsafe_inspect'] = a.call('skill.inspect', {'id':'skill.unsafe'})
    o['skill_version_register'] = a.call('skill.list', {'register':{'schema':'toolhub.skill/v1','id':'skill.version','name':'Version','kind':'package','requires':[{'capability':'language.python.execute','version':'>=999'}],'optional':[{'capability':'language.python.execute','version':'>=999'}]}})
    o['skill_version_inspect'] = a.call('skill.resolve', {'id':'skill.version'})
    o['skill_blocked_register'] = a.call('skill.list', {'register':{'schema':'toolhub.skill/v1','id':'skill.blocked','name':'Blocked','requires':[{'capability':'media.video.transcode'}]}})
    o['skill_blocked_inspect'] = a.call('skill.resolve', {'id':'skill.blocked'})
    o['skill_hooks_rejection'] = a.call('skill.list', {'register':{'id':'skill.hooks','hooks':[]}})
    o['skill_schema_rejection'] = a.call('skill.list', {'register':{'id':'skill.v999','schema':'toolhub.skill/v999'}})
    # Exercise a harmless child CLI parse error; it cannot mutate installed software.
    env = dict(BASE, TOOLHUB_PRINCIPAL='probe.owner')
    apr = subprocess.run([str(CLI),'--json','approve','safe.inst','--','__probe_invalid_command__'],env=env,capture_output=True,text=True,encoding='utf-8',timeout=5)
    o['cli_approve_exit'] = apr.returncode
    aid = json.loads(apr.stdout)['approval_id']
    ex = subprocess.run([str(CLI),'--json','exec','safe.inst','--approval-id',aid,'--','__probe_invalid_command__'],env=env,capture_output=True,text=True,encoding='utf-8',timeout=5)
    o['cli_child_failure'] = {'exit':ex.returncode,'stdout':json.loads(ex.stdout),'stderr':ex.stderr[:300]}
    o['activity_after_execution'] = a.call('activity.list')
    missing = subprocess.run([str(CLI),'--json','inspect','not.existing'],env=env,capture_output=True,text=True,encoding='utf-8',timeout=5)
    o['cli_missing'] = {'exit':missing.returncode,'stdout':json.loads(missing.stdout)}
    for args in [['discovery','classify','x'],['skill','register','x'],['activity'],['import']]:
        r = subprocess.run([str(CLI),'--json']+args,env=env,capture_output=True,text=True,encoding='utf-8',timeout=5)
        o['cli_command_'+'_'.join(args[:2])] = {'exit':r.returncode,'stderr':r.stderr[:250]}
    m = Rpc([str(CLI),'--json','mcp','serve']); clients.append(m)
    o['mcp_unsupported_version'] = m.call('initialize',{'protocolVersion':'2099-01-01','capabilities':{},'clientInfo':{'name':'probe','version':'1'}})
    o['mcp_initialized_notification'] = m.raw(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized'}),wait=0.2)
    o['mcp_tools_list'] = m.call('tools/list')
    o['mcp_missing_error'] = m.call('tools/call',{'name':'inspect_tool','arguments':{'id':'missing'}})
    o['mcp_error_then_success'] = m.call('tools/call',{'name':'search_tools','arguments':{'query':'Safe'}})
    o['mcp_invalid_input'] = m.call('tools/call',{'name':'search_tools','arguments':{'query':42}})
    o['mcp_invalid_jsonrpc'] = m.call('tools/list',jsonrpc='1.0')
    o['mcp_invalid_id'] = m.call('tools/list',id={'bad':True})
    o['mcp_oversize_reply'] = m.call('tools/list',{'pad':'x'*(1024*1024)})
    o['mcp_parse_error'] = m.raw('{')
    time.sleep(0.1)
    o['mcp_process_after_parse_error'] = m.p.poll()
    con=sqlite3.connect(DB)
    o['persisted_classifications'] = con.execute("SELECT entity_id,confidence,detail FROM evidence WHERE source='ai_classification' ORDER BY id").fetchall()
    o['persisted_execution_count'] = con.execute('SELECT count(*) FROM execution_records').fetchone()[0]
    o['persisted_skills_count'] = con.execute('SELECT count(*) FROM skills').fetchone()[0]
    con.close()
finally:
    for client in clients:
        client.stop()
    (ROOT/'PROTOCOL-PROBES.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(ROOT/'PROTOCOL-PROBES.json'),'observations':len(OUT['observations'])}))
