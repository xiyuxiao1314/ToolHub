param([string]$Phase = 'red')
$ErrorActionPreference = 'Stop'
$env:CARGO_TARGET_DIR = Join-Path $env:TEMP 'toolhub-codex-r2-7a1ba39-target'
$vsVars = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$cargoExecutable = 'C:\Users\hp\.cargo\bin\cargo.exe'
Set-Location -LiteralPath (Join-Path $PSScriptRoot 'checkout')
$logFile = Join-Path $PSScriptRoot ('evidence\policy-' + $Phase + '.log')
$nativeCommand = 'call "' + $vsVars + '" >nul && "' + $cargoExecutable + '" test --offline --locked --no-fail-fast -p toolhub-registry -p toolhub-daemon policy_'
& $env:ComSpec /d /s /c $nativeCommand *> $logFile
$testExit = $LASTEXITCODE
Get-Content -LiteralPath $logFile -Tail 35
[ordered]@{phase=$Phase; exit_code=$testExit; log=$logFile} | ConvertTo-Json
if ($Phase.StartsWith('red') -and $testExit -eq 0) { throw 'Expected regression did not fail before correction' }
if (-not $Phase.StartsWith('red') -and $testExit -ne 0) { throw 'Correction regression failed' }
