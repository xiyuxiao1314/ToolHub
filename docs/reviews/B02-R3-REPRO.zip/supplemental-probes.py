import json, os, pathlib, queue, sqlite3, subprocess, threading, uuid
ROOT=pathlib.Path(__file__).resolve().parent
CASE=ROOT/('supplement-'+uuid.uuid4().hex[:8]); CASE.mkdir()
DB=CASE/'registry.sqlite'; BIN=ROOT/'bin'
ENV=dict(os.environ,TOOLHUB_REGISTRY=str(DB),TOOLHUBD_BIN=str(BIN/'toolhubd.exe'))
ENV.pop('TOOLHUB_ADMIN',None); ENV.pop('TOOLHUB_PRINCIPAL',None)
class Rpc:
    def __init__(self,args):
        self.log=open(CASE/(uuid.uuid4().hex+'.log'),'w',encoding='utf-8')
        self.p=subprocess.Popen(args,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
        self.q=queue.Queue();self.id=0
        def read():
            for line in self.p.stdout:self.q.put(line)
            self.q.put(None)
        threading.Thread(target=read,daemon=True).start()
    def raw(self,s,wait=3):
        self.p.stdin.write(s+'\n');self.p.stdin.flush()
        try:l=self.q.get(timeout=wait)
        except queue.Empty:return {'no_response_within_ms':int(wait*1000)}
        return json.loads(l) if l else {'eof':True}
    def call(self,m,p=None):
        self.id+=1;return self.raw(json.dumps({'jsonrpc':'2.0','id':self.id,'method':m,'params':p or {}}))
    def close(self):
        if self.p.poll() is None:
            self.p.stdin.close()
            try:self.p.wait(timeout=2)
            except subprocess.TimeoutExpired:self.p.kill();self.p.wait(timeout=2)
        self.log.close()
out={'reviewed_head':'b62604095b248e7c13d44cfdfba8e789c0503c89','observations':{}}
o=out['observations'];a=Rpc([str(BIN/'toolhubd.exe')]);a.call('ping')
with sqlite3.connect(DB) as c:
    c.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES('fixture.version','Version fixture','t','t')")
    c.execute("INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,environment_id,trust_json,status,first_seen,last_seen) VALUES('fixture-version','fixture.version','3.13.0','windows','x86_64','owned-unexecuted-fixture.exe','env.user','{\"level\":\"known\"}','available','t','t')")
    c.execute("INSERT INTO tool_capabilities(definition_id,capability_id) VALUES('fixture.version','language.python.execute')")
o['invalid_constraint_with_stable_provider']=a.call('resolve.capability',{'capability':'language.python.execute','version':'>=banana'})
o['invalid_object_id']=a.raw('{"jsonrpc":"2.0","id":{"bad":1},"method":"ping"}')
o['valid_after_malformed']=a.raw('not-json');o['ping_after_malformed']=a.call('ping')
export=a.call('export.report',{})
o['report_export_keys']=list(export.get('result',{}))
o['own_export_import']=a.call('export.report',{'import':export.get('result',{})})
o['notification_policy_mutation']=a.raw('{"jsonrpc":"2.0","method":"policy.set","params":{"scope":"tool","subject":"fixture.notification","action":"deny"}}',.2)
o['policy_after_notification']=a.call('policy.get')
a.close()
m=Rpc([str(BIN/'toolhub.exe'),'mcp','serve'])
o['mcp_unsupported_version']=m.call('initialize',{'protocolVersion':'2099-01-01'})
o['mcp_wrong_query_type']=m.call('tools/call',{'name':'search_tools','arguments':{'query':42}})
o['mcp_malformed_json']=m.raw('not-json')
m.close();o['mcp_exit_after_malformed']=m.p.returncode
fake_root=CASE/'metadata-only/bin';fake_root.mkdir(parents=True)
fake=fake_root/'python.exe';fake.write_bytes(b'MZ'+b'\0'*2046)
ENV.update(TOOLHUB_REGISTRY=str(CASE/'mz.sqlite'),PATH=str(fake_root),ProgramFiles=str(CASE),LOCALAPPDATA=str(CASE))
ENV['ProgramFiles(x86)']=str(CASE)
scan=Rpc([str(BIN/'toolhubd.exe')]);scan.call('scan.start',{'mode':'quick'});scan.close()
with sqlite3.connect(CASE/'mz.sqlite') as c:
    o['invalid_mz_metadata_fixture_trust']=c.execute("SELECT json_extract(trust_json,'$.level'),version,arch FROM tool_instances WHERE path=?",(str(fake),)).fetchone()
(ROOT/'evidence/supplemental-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('supplemental_observations='+str(len(o)))
