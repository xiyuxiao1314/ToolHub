import json, os, pathlib, shutil, socket, sqlite3, subprocess, sys, time, uuid
sys.stdout.reconfigure(encoding='utf-8')
ROOT = pathlib.Path(__file__).resolve().parent
CASE = ROOT / ('desktop-' + uuid.uuid4().hex[:8]); CASE.mkdir()
BIN = ROOT / 'bin'; DB = CASE / 'registry.sqlite'
ENV = dict(os.environ, TOOLHUB_REGISTRY=str(DB), TOOLHUBD_BIN=str(BIN/'toolhubd.exe'))
ENV.pop('TOOLHUB_ADMIN', None); ENV.pop('TOOLHUB_PRINCIPAL', None)
subprocess.run([str(BIN/'toolhubd.exe')], input='{"jsonrpc":"2.0","id":1,"method":"ping"}\n', env=ENV, text=True, encoding='utf-8', capture_output=True, timeout=5, check=True)
with sqlite3.connect(DB) as conn:
    conn.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES('fixture.python','Fixture Python','t','t')")
    conn.execute("INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,environment_id,trust_json,status,first_seen,last_seen) VALUES('fixture-python','fixture.python','3.13','windows','x86_64','owned-fixture-python.exe','env.user','{\"level\":\"unknown\"}','available','t','t')")
    conn.execute("INSERT INTO tool_capabilities(definition_id,capability_id) VALUES('fixture.python','language.python.execute')")
# Intercept best-effort auto-browser launch with the already reviewed CLI binary.
# Only this fixture process PATH is affected; browser testing uses Codex IAB.
shim = CASE / 'launch-shim'; shim.mkdir(); shutil.copyfile(BIN/'toolhub.exe', shim/'cmd.exe')
ENV['PATH'] = str(shim) + os.pathsep + ENV.get('PATH','')
s = socket.socket(); s.bind(('127.0.0.1',0)); PORT = s.getsockname()[1]; s.close()
ENV['TOOLHUB_DESKTOP_PORT'] = str(PORT)
log = open(CASE/'desktop.log','w',encoding='utf-8')
p = subprocess.Popen([str(BIN/'toolhub-desktop.exe')],env=ENV,stdout=subprocess.DEVNULL,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
for _ in range(50):
    if p.poll() is not None: raise RuntimeError('Desktop exited: '+(CASE/'desktop.log').read_text())
    try:
        conn=socket.create_connection(('127.0.0.1',PORT),timeout=.2); conn.close(); break
    except OSError: time.sleep(.05)
result={'reviewed_head':'b62604095b248e7c13d44cfdfba8e789c0503c89','pid':p.pid,'port':PORT,'url':f'http://127.0.0.1:{PORT}/','fixture_database':str(DB)}
(ROOT/'evidence/desktop-fixture.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
