# ToolHub R3 — independent authority, IPC and execution source review

Reviewed head: `b62604095b248e7c13d44cfdfba8e789c0503c89`; comparison base: `6df2166e0c55ec64667021e386e75ca93acb066d`. Checkout: `<REVIEW_ROOT>\checkout`.

This is a source-only lane of the single consolidated R3, not another formal round or acceptance decision. No product edits, tests, application launches, attack demonstrations, workbench or cloud messages were performed. All anchors below are verified one-based lines at the stated head; paths are repository-relative. Suggested regressions are conceptual, harmless fixture requirements, not executed results.

Inputs included checkout `AGENTS.md`, baseline/security/protocol documents, relevant full-design sections, the two-batch plan, and authoritative `D:\ToolHub\docs\tasks\MIMO-B02-INTEGRATED-PRODUCT.md` and `D:\ToolHub\docs\reviews\B01-R2-RESULT.md`. Real daemon/client/executor/registry call paths and relevant test source were examined; developer self-assessment and test names were not treated as closure evidence.

## Prioritized actionable findings

### A01 [P1] Trusted approval and policy authority remain environment declarations

**Anchors:** `apps/daemon/src/service.rs:83–99`, `:535–540`, `:966–974`; `apps/cli/src/main.rs:330–335`; `apps/desktop/src/main.rs:48–55`, `:74–100`.

`peer_principal()` falls back to daemon-global `TOOLHUB_PRINCIPAL`; `is_admin()` grants authority from a `local.admin` prefix or `TOOLHUB_ADMIN=1`. Private stdio daemons inherit the client's environment. No transport-authenticated approver/controller is established. Adding an `is_admin()` check before approval issuance improves the default rejection path, but moves the assertion into inherited configuration. `policy.set` gates only **Allow**: an ordinary caller can replace an existing Deny with Ask, including malformed actions mapped to Ask, and remove the stronger prohibition. This is expressly the unresolved R2-B01 case.

The new desktop exposes `/rpc` on loopback and forwards the received body into its one private daemon without a method/origin/session/peer check. Every local requester receives that daemon's principal; when the process inherits admin configuration it shares that controller authority through the proxy. This is a newly added authority surface, not evidence of a demonstrated browser or cross-user exploit.

**Fix:** establish an authenticated control channel and independent caller/approver roles; authorize every authority-changing replacement against the previous effective rule, validate action/scope strictly, and carry verified peer identity through desktop and service dispatch.

**Safe conceptual regression:** an ordinary identified client cannot issue approval, replace Deny with Ask, or impersonate the controller by changing a label/environment; a separate authorized controller can approve the ordinary client's exact request. A loopback request outside the desktop session cannot reuse its controller authority.

**Disposition:** R2-B01 remains open; desktop proxy adds a new surface.

### A02 [P1] Shared IPC identity is an ephemeral connection label; default Ask has no usable shared approver

**Anchors:** `apps/daemon/src/main.rs:83–95`, `:134–138`; `crates/ipc/src/lib.rs:98–100`, `:120–141`, `:153–173`; `apps/daemon/src/service.rs:94–99`, `:573–575`, `:741–743`, `:778–782`, `:802–810`.

Windows accepts a connection then labels it `pipe.conn.<timestamp>`. There is no client token/SID/PID verification in accept or service dispatch. The endpoint uses the `USERNAME` environment string; creation passes null security attributes, and the client does not validate daemon ownership. A connection label separates two live connections but does not authenticate a caller or represent a stable principal/session. Unix invokes `handle()` directly and retains the global stdio/environment principal for every peer.

All Windows `pipe.*` principals are explicitly barred from `is_admin()`. Hence every normal shared CLI/MCP connection is denied approval issuance, irrespective of the controller's environment. Approvals are issued to the issuer's own principal, with no separate beneficiary/controller mechanism. The shared default Ask path therefore has neither a trusted controller route nor a usable cross-client approval handoff. Reconnecting also changes ownership: a discovery session created by one short-lived CLI connection cannot be listed, inspected or revoked by a later connection from that same caller, even after its session is loaded from storage.

**Fix:** authenticate OS peers, bind stable caller identity separately from connection/session identity, verify endpoint ownership, and implement explicit controller issuance for a specified authenticated caller/session. Scope session recovery/reconnect deliberately.

**Safe conceptual regression:** two legitimate sequential CLI connections recover the caller's session while another caller cannot; an authorized controller and an ordinary execution client complete one Ask approval through the shared service without spoofed principal labels.

**Disposition:** R2-B01/B02/B08 partial/open. Windows accept/connect code is a real improvement, but role usability and authenticated persistence are unresolved/newly exposed.

### A03 [P1] Clients still run independent daemon state; policy and revocation do not become current across clients

**Anchors:** `apps/cli/src/main.rs:317–345`; `apps/desktop/src/main.rs:30`, `:48–61`; `apps/daemon/src/service.rs:42–67`, `:427–429`, `:796–816`, `:832–845`, `:898`, `:931–935`, `:975–979`.

CLI/MCP opportunistically connect to a Windows pipe, then silently private-spawn on any connect failure; desktop always private-spawns, and Unix CLI has no shared-socket connect path. SQLite persistence is shared but the effective policy, approvals and discovery sessions are snapshots loaded only at open. A later policy mutation in one daemon updates only that daemon's engine. Another open daemon can report updated `stored` rules with stale `defaults` and enforce its stale Allow/Ask decision. Discovery inspect/classify likewise check only cached revocation state. The new owner checks help within one process but do not close authoritative revocation across the actual multi-process client architecture.

**Fix:** use one managed authenticated user service with readiness/reconnect, or an explicit current-state revision/refresh scheme covering every operation; eliminate accidental private policy owners. Revocation writes must succeed before reporting success.

**Safe conceptual regression:** keep desktop, CLI and MCP alive together, change Allow to Deny and revoke a session through one, then ensure the other two immediately enforce Deny/revocation and retain service access after desktop closes. Use a synthetic registry and metadata-only session.

**Disposition:** R2-B02/B08 and B02-01/09/16 remain open.

### A04 [P1] Authorization and executor evaluate different policy contexts; capability and effective cwd are absent

**Anchors:** `apps/daemon/src/service.rs:370–403`, `:405–424`, `:472–473`; `crates/executor/src/lib.rs:200–214`, `:229–240`, `:252–269`; `crates/policy/src/lib.rs:85–108`.

Daemon constructs policy context with tool, agent, raw optional cwd and environment, but no capability or command. It decides whether approval must be present/consumed from that incomplete context. The executor then adds a command equal to the executable stem and evaluates policy again. For example, tool-level Ask plus command-level Allow is rejected for missing approval before the executor can use the higher-precedence Allow. Command-level Ask plus tool-level Allow passes the daemon gate but is later rejected because no approval was validated. Capability Deny cannot match at all. An omitted cwd is `None` for directory policy, although the child runs in the daemon's inherited working directory; equivalent relative/absolute paths also do not share effective directory rules.

**Fix:** resolve one canonical runtime cwd and complete capability/command context before deciding, issuing and validating approval; pass that same authorized context to launch. Define command semantics consistently rather than silently synthesizing a second context downstream.

**Safe conceptual regression:** synthetic provider with opposing tool/command rules must produce the documented precedence result through the daemon; capability Deny and an effective-directory Deny must hold when cwd is omitted or expressed equivalently.

**Disposition:** R2-B01 and prior F03 context closure remain open.

### A05 [P1] Approval binding still lacks real session, canonical runtime cwd and policy/trust revisions

**Anchors:** `apps/daemon/src/service.rs:406–415`, `:437–447`, `:562–575`, `:580–599`, `:604–617`, `:628–637`, `:1193–1196`; `crates/executor/src/lib.rs:105–118`, `:146–148`, `:164–180`, `:648–652`; `crates/core/src/execution.rs:44–59`.

The new digest hashes only action string, trust level, status and instance ID. Issuance hardcodes action `ask` and session `cli-session`. Validation only requires a nonempty session string: ExecutionRequest has no session to compare. There is no rule/trust revision, so changing policy/trust away and back leaves an old approval valid; replacing an Ask rule with a different Ask rule also leaves its digest unchanged. cwd still hashes raw optional text, with omitted cwd bound to empty text rather than its launch meaning. Legacy empty policy digests deliberately skip validation. Hash failures still mint an approval with an empty executable hash. Approval save/revoke database failures are ignored, so the API can claim durable issuance/revocation that did not occur.

The executable hash/argv/stdin/environment comparisons, expiry checks and atomic consume are positives, but they do not establish the full binding required by R2-B01.

**Fix:** explicit authenticated session and monotonically changing policy/trust revisions; canonical effective cwd/executable identity; strict nonempty digests and migration invalidation for legacy approvals; propagate issuance/revoke failures.

**Safe conceptual regression:** a session mismatch, daemon restart with a different inherited cwd, an Ask→Deny→Ask revision change, and a failed revoke write must not allow a previously issued approval to be used or falsely reported revoked. Do not launch any real tool for negative assertions.

**Disposition:** R2-B01 remains partial/open.

### A06 [P1] Argument digest is not an unambiguous encoding of argv

**Anchors:** `crates/core/src/execution.rs:117–124`; `crates/executor/src/lib.rs:161–162`, `:648`.

`digest_strings()` appends raw strings separated by byte `0x1f`, without escaping or length-prefixing. Input args accept arbitrary JSON strings (`apps/daemon/src/service.rs:325–332`). Consequently one argument containing the separator and two arguments split at that separator produce the identical preimage byte stream and approval digest. This is an encoding ambiguity, not a SHA-256 collision; different argv vectors can pass the purported exact-argv binding.

**Fix:** hash a canonical length-prefixed vector or canonical serialized array, with versioned digest domain separation and invalidation of old approvals.

**Safe conceptual regression:** compare only digests for a synthetic vector containing U+001F and an otherwise equivalent split vector; assert inequality and rejection after argv changes. No execution or attack demonstration is needed.

**Disposition:** newly identified existing defect (helper unchanged from base); broad R2-B01 exact-request closure remains open.

### A07 [P1] Deadlines still do not bound inherited pipes; cancel does not cancel and blocks behind execution

**Anchors:** `crates/executor/src/lib.rs:285–297`, `:315–317`, `:342–343`, `:358–387`, `:393–411`; `apps/daemon/src/main.rs:94–96`, `:136–138`; `apps/daemon/src/service.rs:472–473`, `:517–533`.

Execution still unconditionally joins all three blocking I/O threads **before** its bounded collector. A descendant retaining stdout/stderr/stdin handles can keep those joins alive beyond the parent timeout; a parent that exits normally never enters the new tree-kill branch. Timeout first kills the parent, then invokes synchronous `taskkill /T` by name, ignoring outcome and imposing no deadline on that helper. Unix has no process-group teardown. The reader's overflow drain also waits for EOF. These paths leave the return deadline unbounded.

`execute.cancel` merely records an activity string and returns `cancelled: true`; no running-process map, cancellation token, child handle or execution ID is supplied to the executor. All client requests lock the single `DaemonService` while synchronous execution runs, so a cancel/ping from another client cannot reach the handler during that operation. The response is therefore materially misleading, not a completed cooperative cancel implementation.

**Fix:** own bounded process-tree lifetime and cancellable pipe teardown, bound every wait/helper, move long operations outside the service mutex, issue execution IDs and route ownership-checked cancellation to the running process.

**Safe conceptual regression:** an owned finite fixture parent exits while an owned finite descendant keeps a pipe briefly open; request completion still respects a short configured bound. While a finite fixture is running, a second client can ping and cancel it, with an observed Cancelled result. No unbounded fixture is necessary.

**Disposition:** R2-B03 remains open; taskkill addition is only a partial source change.

### A08 [P1/P2] Audit/activity omissions and incomplete redaction remain on the real execution path

**Anchors:** `apps/daemon/src/service.rs:345–356`, `:417–429`, `:475–504`, `:982–988`; `crates/audit/src/lib.rs:37–46`; `crates/registry/src/repo.rs:330–348`; `crates/executor/src/lib.rs:542–573`, `:601–624`, `:720–723`.

Trust/status/policy/approval denials return before audit creation. Completed executions insert only `execution_records`; activity.list still queries the separate activity table, so execution and denial do not appear in desktop/CLI activity. The insert error is discarded. Audit stores executable verbatim and passes cwd only through secret-name text masking, leaving private/user paths untouched. Sensitive short-flag values are not recognized: the `-t` fixture appears to assert short-flag masking but its value `SECRETV` is masked because the value itself contains `SECRET`; an opaque synthetic value follows the unchanged plaintext branch. `replace_ci` uses byte offsets from lowercased text to slice the original text, which is unsafe when Unicode lowercase changes byte length; one-byte usernames are skipped explicitly.

**Fix:** record every authorization/execution outcome through the actual activity contract, preserve accurate audit-write failure state, use privacy-aware path/argv redaction and safe Unicode matching. Carry redaction into error paths consistently.

**Safe conceptual regression:** metadata-only denied request and owned successful fixture both appear in activity; audit/error/export with a synthetic home path, Unicode identity and opaque short-flag credential contain neither private path nor credential. An injected audit write failure is observable. This review did not execute those checks.

**Disposition:** R2-B03/B10 and F05 remain partial/open. No persistent stdout in the execution-record schema is a verified source positive.

### A09 [P2] UTF-8 conversion can expand output beyond its advertised byte bound

**Anchors:** `crates/executor/src/lib.rs:311–320`, `:338–346`, `:415–416`, `:460–472`; `crates/protocol/src/lib.rs:65–66`; `crates/ipc/src/lib.rs:26–28`.

Readers cap raw bytes at 256 KiB per stream. `utf8_lossy_cap()` checks the raw input length before replacement decoding; an incomplete/invalid byte is then replaced with a multi-byte character without rechecking the encoded string. Since readers already cap raw bytes, its `bytes.len() > max` branch normally does not run. Returned stdout/stderr can therefore exceed the byte contract; combined expansion can also exceed the 1 MiB frame limit and turn a completed execution into a connection write failure. JSON escaping can further expand a response envelope.

**Fix:** bound final UTF-8 output and final serialized response independently; report truncation accurately and return a bounded structured response.

**Safe conceptual regression:** pure conversion of synthetic invalid UTF-8 and response serialization stay within declared byte limits, including both streams and escaping. No process required.

**Disposition:** the specific R2-B03 output residual remains open.

### A10 [P1/P2] Unix service lifecycle and target-correct compilation remain defective

**Anchors:** `apps/daemon/src/main.rs:76–80`, `:114–125`; `crates/ipc/src/lib.rs:87–92`, `:97–105`; `apps/cli/src/main.rs:319–330`.

The daemon uses `if cfg!(windows)` while calling functions defined only with `#[cfg(windows)]`; the Windows branch is still typechecked on Unix, so the unresolved-symbol compile defect from R2 remains in source. The Unix endpoint is global `/tmp/toolhubd.sock`. Startup still removes any existing endpoint after at most warning about permissions, without checking ownership/live listener, despite the comment saying otherwise. CLI has no Unix shared connect path. On Windows there is no first-instance/readiness lock, and accept failures retry forever rather than establishing single daemon ownership.

**Fix:** compile-time-gate transport branches, use verified user-owned endpoints, distinguish stale from live service, enforce single-instance/readiness and connect/reconnect across supported clients.

**Safe conceptual regression:** target compilation plus owned local endpoint fixtures: a second service start must not unlink/take over a live endpoint; genuine stale owned endpoint recovery and client reconnect must succeed. macOS host verification remains separately required.

**Disposition:** R2-B02 remains partial/open; no platform build or runtime verification was performed in this lane.

## Honest positives and evidence limits

- `crates/registry/src/repo.rs:404–415` still replaces policy rules in one transaction; `apps/daemon/src/service.rs:972–975` still persists before updating memory and propagates failure. The bounded `6df2166` corrections are preserved in source.
- Windows now actually calls `ConnectNamedPipe`, permits multiple pipe instances and retains an accept/retry loop; CLI now attempts a shared connection and drops the service mutex before writing a Windows response. These are meaningful structural improvements, without a verified lifecycle claim.
- Approval validation checks hash, canonical path field, argument/stdin/environment digests, expiry and in-memory consumed/revoked state; the registry's conditional consume prevents concurrent replay of a persisted approval (`repo.rs:388–393`).
- Caller-supplied agent labels no longer choose the execution AgentId. Discovery list/inspect/classify/revoke now include ownership comparisons. Their value is limited by identity and authoritative-state defects above.
- Executor uses direct `Command` argument vectors, clears inherited environment, filters secret-like environment names and bounds raw stream storage. Execution-record persistence omits stdout/stderr. These source properties do not establish bounded runtime return or complete redaction.
- Temporary credentials are an isolated memory map (`crates/agent-bridge/src/temp_credentials.rs:8–25`), with no production caller found in this checkout. Its unit helper does not establish the B02 temporary-provider lifecycle; broader integration coverage belongs to the consolidated review.

Relevant test source is weaker than its labels: `apps/daemon/tests/integration.rs:87–124` creates sequential **private** stdio daemons and never asserts the stated count change; `:128–152` supplies a fabricated `pipe.conn.anon` environment principal and accepts either `denied` or any `approval` substring. `apps/daemon/tests/soak.rs:28–37` also starts a private stdio daemon; `:93–96` accepts an error response as success for mixed requests. None establishes authenticated shared peers, real cancel, concurrent service responsiveness or controller-to-caller approval. No test result, exploitation result or successful platform claim is made here.

**Lane assessment:** the verified source improvements are insufficient to close R2-B01/B02/B03/B08/B10 or the relevant B02 authority/shared-service/cancellation/activity conditions. Keep these groups open for the one consolidated MiMo repair before R4; this lane does not request or consume any additional round.
