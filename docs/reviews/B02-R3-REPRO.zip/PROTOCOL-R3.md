# R3 protocol / MCP / CLI / session source review

Reviewed HEAD: `b62604095b248e7c13d44cfdfba8e789c0503c89`.
Comparison base: `6df2166e0c55ec64667021e386e75ca93acb066d`.
Checkout: `<REVIEW_ROOT>\checkout`.

This is an internal source-only lane of the single formal R3 review, not an additional review round. The consolidated review owns acceptance and the 3/4 review ledger. No source edits, Cargo/build/runtime tests, cloud access, workbench calls, third-party agent launches, or new agents were performed. Findings below are source deductions; prior R2 executed observations are not relabeled as executed on this HEAD. Read the checkout AGENTS/baseline/design/plan/brief/delivery documents and `D:\ToolHub\docs\tasks\MIMO-B02-INTEGRATED-PRODUCT.md` plus prior `B01-R2-RESULT.md`.

## Prioritized actionable groups

### PR3-01 [P1] Discovery identity is tied to a connection, not a caller that can reconnect

Primary anchors: `apps/daemon/src/main.rs:83-95`; `apps/cli/src/main.rs:317-327`; `apps/daemon/src/service.rs:740-774`, `:776-823`, `:830-844`, `:882-898`.

The shared Windows daemon assigns each accepted connection a new `pipe.conn.<timestamp>` principal. `discovery.start` saves that principal as the session owner. Each CLI invocation connects afresh, so `toolhub discovery start` followed by `toolhub discovery inspect <session>` or revoke uses a different principal and fails the owner check; list sees no earlier sessions. Restart also generates new connection principals, so persisted sessions cannot be resumed by their original caller. The requested agent id from the CLI is ignored by start. This fixes within-connection owner comparison but breaks the required cross-process discovery flow; it is not a stable authenticated caller identity.

The owner check also reads only the startup/in-memory session vector (`service.rs:42`, `:804`, `:832`, `:884`). A revocation written by another already-open stdio daemon is not reloaded by the original daemon. Session issue/revoke ignore persistence failures (`:760`, `:898`), allowing successful responses for nondurable issuance/revocation. Candidate-list-only sessions still cannot list candidates: `discovery.list` lists sessions; inspect requires candidate.inspect or metadata.read (`:818-823`).

Required repair: a stable transport-authenticated caller identity and separately bound session credential that survives permitted reconnects; authoritative expiry/revocation checks at use; persist before successful issue/revoke; implement each granted scope. Verify two independent connections for one caller, a distinct caller, restart, stale open daemon, and failed persistence. Coordinate identity/admin transport design with the security lane.

### PR3-02 [P1] Classification still accepts nonexistent candidates and invalid confidence

Primary anchors: `apps/daemon/src/service.rs:846-868`; `crates/registry/src/repo.rs:569-586`; `crates/agent-bridge/src/lib.rs:25-33`.

Classification validates only a nonempty candidate string and label. It never queries candidate existence or membership in an explicitly disclosed/authorized candidate set. `store_classification` writes an evidence entity id directly without validating that entity. Confidence with the wrong type defaults to 0.5; out-of-range values clamp to [0,1] and are accepted. Sessions have no candidate membership/disclosure field. Thus a permitted session can submit enrichment for arbitrary ids, including ids absent from the registry. Evidence provenance is the constant `ai` plus a session string rather than a validated classification record.

Required repair: strict typed classification input with finite in-range confidence, candidate existence and authorized membership/disclosure check, explicit submitter/session provenance, and invalid cases returning typed errors before any evidence write. Preserve the existing absence of execution-trust elevation.

### PR3-03 [P1] JSON-RPC semantics and bounds differ between stdio and shared transports

Primary anchors: `apps/daemon/src/main.rs:43-64`, `:93-99`; `apps/daemon/src/service.rs:114-155`; `crates/ipc/src/lib.rs:34-55`; `crates/protocol/src/lib.rs:16-22`, `:64-68`; `schemas/protocol.schema.json:6-13`.

Stdio parses to Value first and discards any JSON with absent or null id before envelope validation and dispatch. This silently drops `{}`, scalars, null-id requests, and valid notification operations instead of executing valid notifications without replying. The pipe path instead unconditionally writes every `handle_with_principal` response, including replies to notifications. Invalid object/array/bool ids are echoed as the error response id (`service.rs:123-131`). Missing required request fields are classified as ParseError by typed deserialization even when the input is syntactically valid JSON (`main.rs:56-64`). Scalar params are not rejected: dispatch reads fields permissively, so e.g. ping/search with scalar params succeeds, wrong query type becomes an empty search, and execute args drop non-string array members (`service.rs:216-219`, `:325-333`). The published schema itself allows any params value.

Stdio uses unbounded `lines()` and has no request-byte check; MCP has the same issue. The framing helper now checks the 1 MiB size before allocation, a real improvement, but malformed framed JSON ends the connection because `read_request` returns an error and the accept worker's while-let stops (`main.rs:93`; Unix `:134-140`). It emits no structured parse error or valid-following-call recovery. Response framing also uses the request limit and closes the pipe on a large registry/export response, with no pagination/bounded result contract.

Required repair: one boundary parser/validator and explicit notification dispatch/response semantics across transports; bounded line reading before allocation; correct null/invalid-id and invalid-request errors; typed params; recoverable malformed frames where framing remains synchronized; bounded/paginated results. Add protocol-bytes cases for each transport, then a valid call after each invalid call.

### PR3-04 [P1] MCP still terminates on malformed input and lacks lifecycle/schema enforcement

Primary anchors: `apps/cli/src/main.rs:433-458`, `:474-526`, `:529-556`; `crates/mcp/src/lib.rs:28-95`, `:103-139`.

`serde_json::from_str(&line)?` propagates malformed JSON out of `mcp_serve`, causing CLI main to emit its `{ok:false,error:...}` wrapper and exit. Unsupported initialize versions are echoed (`:451`), request `jsonrpc` and id types are never validated, input size is unbounded, and there is no initialization state. tools/list and tools/call are accepted before initialize; the tests deliberately use that behavior. Notification cancellation is simply discarded. Missing/wrong tool argument types default to empty strings/arrays; the gateway never calls the separate meta-input validator. Even that unused validator checks presence rather than field types and accepts the wrong required field, e.g. inspect_tool with query instead of id. Runtime tools/list duplicates the schemas rather than consuming `tool_specs`; resolve's optional version in `crates/mcp` is omitted/ignored by the gateway. search_skills ignores query.

The error.message string repair is present at `:547-554`. However, actual tool execution failures are converted to top-level RPC error -32000, discarding the prepared `result.content/isError` tool-result contract. Unknown MCP methods also become -32000 with generic "tool call failed" rather than MethodNotFound with useful method context. Moreover, an execute_tool response with status failed/timed_out is treated as a successful tool result (`:503-515`, `:530-532`) because only outer RPC errors influence isError.

Required repair: implement the advertised MCP lifecycle/version contract, shared typed schemas and envelope validation, bounded recoverable input, useful standard method/params errors, and tool execution failure content with isError=true. Test malformed JSON then valid initialize/call, unsupported versions, invalid ids/params/types, lifecycle order, denied/failed/timed-out execution, and cancellation. The seven-meta-tool bound is positive and should remain.

### PR3-05 [P1] Frozen DTOs, schemas, negotiation, events and cancellation are not the running contract

Primary anchors: `crates/protocol/src/types.rs:16-43`, `:79-102`; `apps/daemon/src/service.rs:216-219`, `:315-316`, `:517-533`, `:1049-1065`; `crates/resolver/src/lib.rs:20-27`; `crates/protocol/src/lib.rs:11-12`, `:53-68`; `apps/daemon/src/service.rs:26-27`, `:76`; `crates/protocol/src/methods.rs:34-62`.

Search returns InstanceRow objects (id/path/environment_id/status and trust as encoded JSON) rather than the advertised SearchHit (instance_count/capabilities). Resolve returns `canonical`, CandidateInstance with arch/cwd_match and no score, and optional string error rather than ResolveResult's `canonical_capability` and scored ResolvedInstance. Export omits MachineReport.environments and each ReportTool's environment/capabilities. Schema files define only a generic request envelope, without method-specific params/results/events/compatibility. No client/server uses the declared result DTOs to enforce these outputs. The developer guide nevertheless calls the schemas authoritative (`docs/development/DEVELOPER.md:33`), including report/resource/update schema files absent from schemas/.

THP version 1.0 is reported but has no negotiation/version-request method or compatibility gate. EventEnvelope and seq are unused declarations, with no subscription, emit, ordering or backpressure implementation. `execute.cancel` does not identify/control any running execution: it records arbitrary input text to activity and returns cancelled:true, even for an empty or nonexistent execution id. Execution runs synchronously while holding the service mutex (`main.rs:94-96`; `service.rs:472-473`), so a cancellation request cannot reach this branch until the invocation has already finished.

Required repair: freeze one canonical typed wire contract, propagate it through schemas/docs/CLI/MCP/SDK/UI and verify serialized results; implement real bounded operation ids/deadlines/cancel and event delivery with explicit ordering, subscription and reconnect rules. Logging a cancellation request must not report cancellation completion. Coordinate running-operation cancellation with the executor lane.

### PR3-06 [P1/P2] Report import/export and activity remain incomplete user-facing operations

Primary anchors: `apps/daemon/src/service.rs:990-1065`, `:475-504`, `:982-988`; `apps/cli/src/main.rs:20-91`, `:99-122`, `:227-230`; `crates/registry/src/repo.rs:302-312`, `:316-332`.

Import requires `schema=toolhub.report/v1`, but export never emits a schema field, so importing ToolHub's own unmodified export is rejected. Import only checks that schema string, silently skips malformed tool entries, truncates at 500, ignores write failures, and returns a partial success count. Export omits environments/capabilities/provenance and ignores the requested format. Foreign imports are deliberately missing/unknown with no capability mapping; that safety direction is positive, but it is not a validated interoperable report contract.

Successful execution writes only execution_records and ignores that write result. activity.list reads only activity, so executions still do not appear. Early policy/trust/approval denials return before any audit/activity record. Source searches show normal activity writes only for scan and the placeholder cancel path; registry/resolver/execution activity is absent. No CLI activity/import command exists; skill CLI has no resolve/register and discovery CLI has no classify, despite the generated prompt advertising classify (`crates/agent-bridge/src/lib.rs:86-89`).

Required repair: schema-valid report round trip, explicit invalid/partial/limit errors and provenance, useful redacted environment/capability fields, complete CLI commands and redacted scan/registry/resolver/execution/denial activity. Preserve semantic child-failure exits already added at CLI `:281-294` and add an actual fixture-child failure assertion.

### PR3-07 [P1] Connected-agent launch is still manual source, not just an unverified account/host

Primary anchors: `crates/agent-bridge/src/adapters.rs:3-35`, `:87-101`, `:127-135`; `apps/daemon/src/service.rs:901-929`; `apps/cli/src/main.rs:120-122`, `:317-335`; `crates/protocol/src/methods.rs:34-62`.

The adapter trait explicitly implements detect/config/health only; launch_discovery_session returns manual instructions and has no concrete override. No method calls it, spawns/monitors/cancels an agent, or scopes its session credential. agent.list only returns PATH detection, constant health=detected, MCP configuration and a prompt with literal <session>. Version is always None. Generated TOOLHUB_ENDPOINT is ignored by the CLI, which always chooses its own user pipe then private daemon fallback. Missing external agent authorization may explain lack of real-host verification, but cannot explain the absence of a launch/monitor/cancel implementation in delivered source.

Required repair: a genuinely supported adapter launch lifecycle, actual daemon endpoint/session credentials, explicit metadata disclosure and scope, status/monitor/cancel and provenance handling. Unsupported adapters must report that state instead of merely producing launch text. Verify with an owned harmless adapter fixture, then separately mark any actual external runtime check unverified.

### PR3-08 [P1 evidence gap] Soak/integration/MCP tests do not establish shared-pipe or full conformance claims

Primary anchors: `apps/daemon/tests/soak.rs:28-44`, `:79-104`, `:107-126`, `:128-147`, `:150-167`; `apps/daemon/tests/integration.rs:87-124`, `:128-153`; `apps/cli/tests/mcp_conformance.rs:40-50`, `:66-75`, `:99-112`, `:120-149`, `:153-185`; `docs/reviews/B02-INTEGRATED-DELIVERY.md:27-30`; `scripts/smoke.ps1:26-37`, `:43-60`, `:62-77`, `:85-105`.

This review did not execute these tests. Even if the reported passes are accurate, their source proves narrower behavior:

| Test | What its assertions can establish | What it does not establish |
| --- | --- | --- |
| soak 50 requests | One stdio child returns an envelope-shaped line and a final ping | No --listen, pipe, independent caller, concurrent request, semantic success, policy sharing, identity, reconnect or cancellation |
| scan/query interleave | Serial scan then query then activity over one stdin/stdout | No overlapping scan/query or responsive service while executing |
| bad-request recovery | Malformed text followed by valid ping/unknown method can recover over stdio | The "wrong version" line is an ordinary valid ping; no oversized input is ever sent |
| restart durability | A newly spawned daemon returns tool_count after a previous scan | Does not assert count/identity/value equals the previous state or that scan succeeded |
| two_clients_share_registry | Three separate sequential stdio daemons share a DB path and return expected substrings | Does not connect two clients to one daemon or compare persisted state; comment claims increased counts but assertions never check counts |
| approve_requires_admin | A stdio process with principal label pipe.conn.anon returns text containing denied OR approval | No authenticated pipe peer; substring approval can also accept an unrelated approval failure and admin env is not explicitly removed |
| MCP 6 cases | Basic list/content/error-string/next-call replies for a permissive gateway | No lifecycle/version/id/params/size/malformed recovery/cancel; most calls run without initialize; read_line_timeout ignores ms and blocks |

The MCP test spawn does not establish a controlled shared daemon endpoint: CLI first attempts the user pipe and otherwise spawns a child; tests set a private registry path but do not control a real shared endpoint. Thus a preexisting listener can even cause the configured test DB to be ignored. Binary paths can be externally supplied without assertions that they match this revision.

Smoke still writes plain text under an .exe suffix that cannot create its marker, and the fixture directory is not added to the scanned roots/PATH. No-marker is vacuous. The deny section only queries policy; MCP only lists names. Positive exec/replay now benefit from semantic exit handling, but there is no controlled child failure/real activity/discovery isolation/import or protocol boundary assertion.

Required repair: isolated owned shared endpoint, real --listen daemon, independent concurrent CLI/MCP/desktop clients, stable peer/scope tests and semantic parsed-result assertions. Supply bounded test timeouts, runnable in-scope unknown and known harmless fixtures, negative controls that fail on the intended regression, and exact-revision executable/evidence linkage. Reclassify I/V rows for R2-B07/B08/B10 and related targets until the actual integrated behaviors pass.

### PR3-09 [P2] SDK requests can hang forever after daemon disconnect

Primary anchors: `packages/sdk-typescript/src/index.js:50-80`; `packages/sdk-typescript/src/index.d.ts:1-9`.

nodeStdioTransport retains only resolve callbacks and listens only to stdout data. There is no child exit/error/stdout close handler, request deadline, reject/cleanup for pending calls, or bounded response buffer. If the daemon exits after accepting a write, the promise never resolves or rejects. A malformed complete response line is silently discarded with the same result. On write error the promise rejects but the pending entry stays in the map. Every result is any and there is no concrete shared-service socket/pipe transport, typed result model, SDK fixture or usage example in the guide.

Required repair: reject and clean pending requests on transport close/error, deadlines/cancellation and bounded buffering, validate response envelope/id, expose canonical DTOs, and supply a minimal working example plus disconnect/recovery fixtures.

### PR3-10 [P2] Shared version constraints retain the exact R2 grammar/equality faults

Primary anchors: `crates/core/src/version.rs:53-66`, `:69-98`, `:111-128`.

This file is unchanged from the review base. The parser accepts alphabetic banana as a version. Numeric split drops nonnumeric prerelease segments, making 3.13.0-rc1 and 3.13.0-rc2 equal to 3.13.0 for exact equality. Zero-major caret checks only the minor component, so ^0.0.3 accepts 0.0.9. These are direct source deductions, not newly executed examples. They remain relevant to schema/version compatibility, resolver and skill requirement consistency.

Required repair: defined validated version grammar and comparisons shared by all clients/resources/skills, including exact prerelease and ^0.0.x cases; preserve supported abbreviated runtime-version semantics explicitly.

## R2-B07 / B08 / B10 disposition

| R2 group | Visible source improvements | Still open |
| --- | --- | --- |
| B07 | Framed size check before allocation; string MCP error.message; basic seven tools/list and tool content; stdio notification silence | Notification execution/pipe silence, null/invalid ids, typed/scalar params, stdio/MCP size, malformed recovery, MCP lifecycle/version/errors, schema/runtime equality, events/cancel |
| B08 | Per-connection owner comparisons for list/inspect/classify/revoke; persisted session owner and untrusted AI evidence; no classification trust write | Stable authenticated caller/reconnect, candidate existence/member scope, strict confidence/provenance, granted candidate.list behavior, authoritative durable revocation and persistence failure handling |
| B10 | Windows CLI attempts shared pipe; semantic failed/timed_out/cancelled status exits; safe-direction foreign import fields; basic TS client | Actual shared-service evidence, cross-client authorization/availability, executable activity/denial audit, compatible report/CLI import, missing commands, real adapter launch, runnable semantic negatives, bounded SDK lifecycle |

`crates/protocol/src/{lib.rs,types.rs}`, `schemas/protocol.schema.json`, `crates/mcp/src/lib.rs`, `crates/agent-bridge/src/adapters.rs` and core version code have no diff from `6df2166` to this HEAD. The major R2 contract/adapter gaps therefore cannot be treated as repaired merely because new test files or coverage labels exist.

## Review conclusion for consolidation

This lane recommends changes_required for its protocol/MCP/discovery/report/adapter acceptance scope. No runtime success/failure or independent full-platform conformance is claimed. The parent should fold these groups into one consolidated R3 list, cross-reference identity/cancellation/audit findings with the security/data lanes, and send one repair assignment within the existing R3/R4 budget.
