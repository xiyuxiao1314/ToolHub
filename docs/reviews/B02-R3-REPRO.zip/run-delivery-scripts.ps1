$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$checkoutRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot 'checkout')).Path
$expectedDist = [IO.Path]::GetFullPath((Join-Path $checkoutRoot 'dist\toolhub-0.2.0'))
if (-not $expectedDist.StartsWith($checkoutRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Package output escaped review checkout' }
if ($expectedDist -ne [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'checkout\dist\toolhub-0.2.0'))) { throw 'Unexpected package deletion target' }
$release = Join-Path $checkoutRoot 'target\release'
New-Item -ItemType Directory -Path $release -Force | Out-Null
foreach ($name in @('toolhub.exe','toolhubd.exe','toolhub-desktop.exe')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('bin\' + $name)) -Destination $release
}
$env:USERNAME = 'codex-r3-scripts-' + [guid]::NewGuid().ToString('n').Substring(0,8)
$results = @()
foreach ($name in @('smoke','package')) {
    $log = Join-Path $PSScriptRoot ('evidence\' + $name + '.log')
    & 'D:\codex\apps\PowerShell\7\pwsh.exe' -NoProfile -File (Join-Path $checkoutRoot ('scripts\' + $name + '.ps1')) *> $log
    $code = $LASTEXITCODE
    $results += [pscustomobject]@{script=$name;exit_code=$code;log=$log}
    Write-Host "$name exit=$code"
    Get-Content -LiteralPath $log -Tail 3 | Write-Host
}
$pkgFiles = @(Get-ChildItem -LiteralPath $expectedDist -Recurse -File | ForEach-Object { $_.FullName.Substring($expectedDist.Length+1) })
$version = & (Join-Path $release 'toolhub.exe') --version
$result = [ordered]@{reviewed_head='b62604095b248e7c13d44cfdfba8e789c0503c89';checks=$results;package_files=$pkgFiles;binary_version=$version;package_label='0.2.0'}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'evidence\delivery-scripts.json'),($result | ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
if (@($results | Where-Object exit_code -ne 0).Count -gt 0) { exit 1 }
