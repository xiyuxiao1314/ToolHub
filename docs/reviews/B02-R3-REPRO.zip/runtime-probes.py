"""R3 safe QA on owned private databases and finite print/sleep fixtures."""
import json, os, pathlib, queue, shutil, sqlite3, struct, subprocess, sys, threading, time, uuid

ROOT = pathlib.Path(__file__).resolve().parent
CASE = ROOT / ('runtime-' + uuid.uuid4().hex[:8])
CASE.mkdir()
BIN = ROOT / 'bin'
DAEMON, CLI = BIN / 'toolhubd.exe', BIN / 'toolhub.exe'
DB = CASE / 'registry.sqlite'
BASE = dict(os.environ, TOOLHUB_REGISTRY=str(DB), TOOLHUBD_BIN=str(DAEMON), USERNAME='codex-r3-' + uuid.uuid4().hex[:8])
BASE.pop('TOOLHUB_ADMIN', None)
BASE.pop('TOOLHUB_PRINCIPAL', None)
OUT = {'reviewed_head': 'b62604095b248e7c13d44cfdfba8e789c0503c89', 'observations': {}}
O = OUT['observations']
clients, pipes = [], []
listener = None

class Rpc:
    def __init__(self, principal=None, admin=False, env=None, command=None):
        e = dict(BASE if env is None else env)
        if principal is not None: e['TOOLHUB_PRINCIPAL'] = principal
        if admin: e['TOOLHUB_ADMIN'] = '1'
        self.log = open(CASE / ('stderr-' + uuid.uuid4().hex[:8] + '.log'), 'w', encoding='utf-8')
        self.p = subprocess.Popen(command or [str(DAEMON)], env=e, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log, text=True, encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW)
        self.q = queue.Queue(); self.seq = 0
        def read():
            for line in self.p.stdout: self.q.put(line)
            self.q.put(None)
        threading.Thread(target=read, daemon=True).start()
        clients.append(self)
    def raw(self, value, wait=3):
        line = value if isinstance(value, str) else json.dumps(value)
        self.p.stdin.write(line + '\n'); self.p.stdin.flush()
        try: response = self.q.get(timeout=wait)
        except queue.Empty: return {'no_response_within_ms': int(wait * 1000)}
        if response is None: return {'eof': True, 'exit_code': self.p.poll()}
        return json.loads(response)
    def call(self, method, params=None):
        self.seq += 1
        return self.raw({'jsonrpc': '2.0', 'id': self.seq, 'method': method, 'params': params if params is not None else {}})
    def close(self):
        if self.p.poll() is None:
            self.p.stdin.close()
            try: self.p.wait(timeout=2)
            except subprocess.TimeoutExpired: self.p.kill(); self.p.wait(timeout=2)
        self.log.close()

class Pipe:
    def __init__(self, endpoint):
        end = time.monotonic() + 5
        while True:
            try: self.f = open(endpoint, 'r+b', buffering=0); break
            except OSError:
                if time.monotonic() > end: raise
                time.sleep(.05)
        self.q = queue.Queue(); self.seq = 0
        pipes.append(self)
    def raw(self, value):
        body = json.dumps(value).encode(); self.f.write(struct.pack('>I', len(body)) + body)
        def read():
            try:
                size = self.f.read(4)
                if len(size) != 4: self.q.put({'eof':True}); return
                size = struct.unpack('>I', size)[0]
                data = b''
                while len(data) < size:
                    part = self.f.read(size - len(data))
                    if not part: break
                    data += part
                self.q.put(json.loads(data))
            except (OSError, ValueError): pass
        threading.Thread(target=read, daemon=True).start()
        try: return self.q.get(timeout=3)
        except queue.Empty: return {'no_response_within_ms': 3000}
    def call(self, method, params=None):
        self.seq += 1
        return self.raw({'jsonrpc':'2.0','id':self.seq,'method':method,'params':params or {}})

try:
    init = Rpc(); O['initial_ping'] = init.call('ping'); init.close()
    with sqlite3.connect(DB) as c:
        c.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES('fixture.python','Fixture Python','t','t')")
        c.execute("INSERT INTO tool_instances(id,definition_id,version,platform,arch,path,canonical_path,environment_id,trust_json,status,first_seen,last_seen) VALUES('fixture-python','fixture.python','3.13.0-rc1','windows','aarch64',?,?,'env.user','{\"level\":\"known\"}','available','t','t')", (sys.executable, sys.executable))
        c.execute("INSERT INTO tool_capabilities(definition_id,capability_id) VALUES('fixture.python','language.python.execute')")
    ordinary = Rpc('fixture.owner')
    O['ordinary_approve_denied'] = ordinary.call('execute.approve', {'instance_id':'fixture-python','args':[]})
    O['invalid_scalar_params'] = ordinary.call('registry.search', 7)
    O['notification_silence'] = ordinary.raw({'jsonrpc':'2.0','method':'ping'}, .25)
    O['ping_after_notification'] = ordinary.call('ping')
    O['oversized_stdio'] = ordinary.call('ping', {'padding':'a' * 1048700})
    O['cancel_nonexistent'] = ordinary.call('execute.cancel', {'execution_id':'owned-nonexistent'})
    O['skill_bad_kind_registration'] = ordinary.call('skill.list', {'register':{'id':'bad-kind','kind':'bogus','requires':'wrong','instruction_file':'\\outside'}})
    O['skill_bad_kind_resolve'] = ordinary.call('skill.resolve', {'id':'bad-kind'})
    ordinary.call('skill.list', {'register':{'id':'requires-new','name':'New version','requires':[{'capability':'language.python.execute','version':'>=999'}]}})
    O['skill_wrong_version'] = ordinary.call('skill.resolve', {'id':'requires-new'})
    O['resolver_actual_arch'] = ordinary.call('resolve.capability', {'capability':'language.python.execute','arch':'x86_64'})
    O['resolver_invalid_version'] = ordinary.call('resolve.capability', {'capability':'language.python.execute','version':'>=banana'})
    O['resolver_exact_prerelease'] = ordinary.call('resolve.capability', {'capability':'language.python.execute','version':'=3.13.0'})
    sid = ordinary.call('discovery.start', {})['result']['session_id']
    other = Rpc('fixture.other')
    O['other_session_inspect_denied'] = other.call('discovery.inspect', {'id':sid})
    O['classify_nonexistent_candidate'] = ordinary.call('discovery.classify', {'session_id':sid,'candidate_id':'not-in-registry','label':'Fixture metadata','confidence':2})
    same = Rpc('fixture.owner')
    O['revoke_in_other_process'] = same.call('discovery.revoke', {'session_id':sid})
    O['stale_process_classification'] = ordinary.call('discovery.classify', {'session_id':sid,'candidate_id':'not-in-registry','label':'Fixture metadata after revoke','confidence':.5})
    admin = Rpc('local.admin', True)
    O['admin_deny_policy'] = admin.call('policy.set', {'scope':'tool','subject':'fixture.python','action':'deny'})
    O['ordinary_replace_deny_with_ask'] = ordinary.call('policy.set', {'scope':'tool','subject':'fixture.python','action':'ask'})
    admin.close()
    admin = Rpc('local.admin', True)
    def run_code(code, timeout=2000):
        arguments = ['-c', code]
        approval = admin.call('execute.approve', {'instance_id':'fixture-python','args':arguments})
        assert 'result' in approval, approval
        start = time.monotonic()
        result = admin.call('execute.tool', {'instance_id':'fixture-python','args':arguments,'approval_id':approval['result']['approval_id'],'timeout_ms':timeout})
        return {'requested_timeout_ms':timeout,'elapsed_ms':round((time.monotonic()-start)*1000),'response':result}
    O['approved_safe_execution'] = run_code('print("R3_SAFE")')
    child = 'import time; print("R3_FINITE_CHILD",flush=True); time.sleep(.8)'
    parent = f'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",{child!r}]); print("R3_PARENT_READY",flush=True); time.sleep(2)'
    O['finite_descendant_timeout'] = run_code(parent, 150)
    O['utf8_output_cap'] = run_code('import sys; sys.stdout.buffer.write(b"a"+("é"*131073).encode())')
    out_result = O['utf8_output_cap']['response'].get('result', {})
    if 'stdout' in out_result:
        out_result['stdout_bytes'] = len(out_result.pop('stdout').encode())
    O['execution_activity'] = admin.call('activity.list')
    O['ping_after_execution'] = admin.call('ping')
    (ROOT / 'evidence/runtime-results.json').write_text(json.dumps(OUT, ensure_ascii=False, indent=2), encoding='utf-8')
    # Actual named-pipe service under a unique owned endpoint.
    log = open(CASE / 'listener.log', 'w', encoding='utf-8')
    listener = subprocess.Popen([str(DAEMON),'--listen'], env=BASE, stdout=subprocess.DEVNULL, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
    endpoint = '\\\\.\\pipe\\toolhubd-' + BASE['USERNAME']
    a = Pipe(endpoint); b = Pipe(endpoint)
    O['pipe_ping_a'] = a.call('ping'); O['pipe_ping_b'] = b.call('ping')
    pipe_sid = a.call('discovery.start', {})['result']['session_id']
    O['pipe_other_session_denied'] = b.call('discovery.inspect', {'id':pipe_sid})
    reconnect = Pipe(endpoint)
    O['pipe_same_user_new_connection_session'] = reconnect.call('discovery.inspect', {'id':pipe_sid})
    O['pipe_notification_response'] = b.raw({'jsonrpc':'2.0','method':'ping'})
    O['pipe_approve_denied'] = b.call('execute.approve', {'instance_id':'fixture-python','args':[]})
    (ROOT / 'evidence/runtime-results.json').write_text(json.dumps(OUT, ensure_ascii=False, indent=2), encoding='utf-8')
    # Native scan fixture; copied real PE and plain text are metadata-only.
    fixture = CASE / 'scan-fixture'
    project_roots = [fixture / 'tenant-a/same/.venv/Scripts', fixture / 'tenant-b/same/.venv/Scripts']
    for path in project_roots:
        path.mkdir(parents=True); shutil.copyfile(sys.executable, path / 'python.exe')
    plain = fixture / 'plain/bin'; plain.mkdir(parents=True)
    (plain / 'python.exe').write_bytes(b'R3 harmless text metadata only')
    scan_db = CASE / 'scan.sqlite'
    scan_env = dict(BASE, TOOLHUB_REGISTRY=str(scan_db), PATH=os.pathsep.join(map(str,[plain,*project_roots])), ProgramFiles=str(fixture), LOCALAPPDATA=str(fixture))
    scan_env['ProgramFiles(x86)'] = str(fixture)
    scan = Rpc(env=scan_env)
    O['native_scan_first'] = scan.call('scan.start', {'mode':'quick'})
    with sqlite3.connect(scan_db) as c:
        O['native_fixture_rows_first'] = c.execute("SELECT id,environment_id,status,trust_json FROM tool_instances WHERE path LIKE ?", ('%' + CASE.name + '%',)).fetchall()
    O['native_scan_second'] = scan.call('scan.start', {'mode':'quick'})
    with sqlite3.connect(scan_db) as c:
        O['native_fixture_rows_second'] = c.execute("SELECT id,environment_id,status,json_extract(trust_json,'$.level') FROM tool_instances WHERE path LIKE ?", ('%' + CASE.name + '%',)).fetchall()
        O['environment_roots'] = c.execute("SELECT id,kind,root_path,parent_id FROM environments WHERE id NOT IN ('env.user','env.system')").fetchall()
        c.execute("INSERT INTO tool_definitions(id,name,created_at,updated_at) VALUES('fixture.outside','Outside fixture','t','t')")
        c.execute("INSERT INTO tool_instances(id,definition_id,platform,arch,path,environment_id,trust_json,status,first_seen,last_seen) VALUES('outside-instance','fixture.outside','windows','x86_64','owned-unvisited-fixture.exe','env.user','{\"level\":\"known\"}','available','t','t')")
    O['native_scan_partial'] = scan.call('scan.start', {'mode':'quick'})
    with sqlite3.connect(scan_db) as c:
        O['unvisited_status_after_quick'] = c.execute("SELECT status FROM tool_instances WHERE id='outside-instance'").fetchone()[0]
finally:
    if listener and listener.poll() is None: listener.kill(); listener.wait(timeout=3)
    for p in pipes:
        try: p.f.close()
        except OSError: pass
    for c in clients:
        try: c.close()
        except (OSError, ValueError): pass
    (ROOT / 'evidence/runtime-results.json').write_text(json.dumps(OUT, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'observations':len(O),'result_path':str(ROOT / 'evidence/runtime-results.json')}, ensure_ascii=False))
