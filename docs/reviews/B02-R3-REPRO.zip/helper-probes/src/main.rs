use serde_json::json;
use sha2::{Digest, Sha256};

fn main() {
    let root = std::env::current_dir().unwrap().join(format!("owned-fixture-{}",std::process::id()));
    std::fs::create_dir_all(&root).unwrap();
    let payload = root.join("payload.bin");
    std::fs::write(&payload,b"owned good payload").unwrap();
    let hash = hex::encode(Sha256::digest(b"owned good payload"));
    let manifest = root.join("manifest.json");
    std::fs::write(&manifest,serde_json::to_vec(&json!({"schema":"toolhub.update/v1","product":"toolhub","version":"banana","min_current":"999.0.0","checksum_sha256":hash,"payload_path":"payload.bin"})).unwrap()).unwrap();
    let verified = toolhub_agent_bridge::update::verify_package(&manifest).unwrap();
    let dest=root.join("installed.bin");
    std::fs::write(&dest,b"owned previous artifact").unwrap();
    let result=toolhub_agent_bridge::update::apply_update(&verified,&dest,&||false);
    let resource=root.join("resource.json");
    std::fs::write(&resource,serde_json::to_vec(&json!({"schema":"toolhub.resource/v1","name":"owned","version":"banana","kind":"bogus","capabilities":["."],"tools":[true]})).unwrap()).unwrap();
    let resource_result=toolhub_recognizer::resources::load_package(&resource);
    let one=toolhub_core::execution::digest_strings(&["a\u{1f}b".to_string()]);
    let two=toolhub_core::execution::digest_strings(&["a".to_string(),"b".to_string()]);
    let out=json!({
        "reviewed_head":"b62604095b248e7c13d44cfdfba8e789c0503c89",
        "update_bad_version_and_minimum_verified":true,
        "update_relative_payload_apply_error":result.err().map(|e|e.to_string()),
        "previous_artifact_exists_after_failed_apply":dest.exists(),
        "previous_backup_exists":dest.with_extension("bak").exists(),
        "malformed_resource_accepted":resource_result.is_ok(),
        "nonnumeric_resource_compatibility_accepted":toolhub_recognizer::resources::is_compatible("1.2.0","banana"),
        "different_argv_same_digest":one==two
    });
    println!("{}",serde_json::to_string_pretty(&out).unwrap());
}
